import { describe, expect, it } from "vitest";

import {
  analyseBars,
  calculateNetPosition,
  calculateReturns,
  calculateSignalScore,
  calculateVolumeZScore,
  calculateZScore,
  classifySignal,
  standardDeviation,
  summariseSignals,
  withWeeklyChanges,
} from "../lib/analytics";
import type { CotObservation, MarketBar } from "../lib/types";

function bar(timestamp: string, close: number, volume: number): MarketBar {
  return { timestamp, open: close, high: close, low: close, close, volume };
}

describe("calculateReturns", () => {
  it("computes simple returns against the previous close", () => {
    const returns = calculateReturns([100, 110, 99]);
    expect(returns[0]).toBeNull();
    expect(returns[1]).toBeCloseTo(0.1, 10);
    expect(returns[2]).toBeCloseTo(-0.1, 10);
  });

  it("returns an empty array for no input", () => {
    expect(calculateReturns([])).toEqual([]);
  });

  it("has no return for the first observation", () => {
    expect(calculateReturns([100])).toEqual([null]);
  });

  it("does not divide by a non-positive previous close", () => {
    expect(calculateReturns([0, 50])).toEqual([null, null]);
  });
});

describe("standardDeviation", () => {
  it("uses the sample formula", () => {
    expect(standardDeviation([2, 4, 4, 4, 5, 5, 7, 9])).toBeCloseTo(2.1381, 4);
  });

  it("is undefined for fewer than two observations", () => {
    expect(standardDeviation([5])).toBeNull();
    expect(standardDeviation([])).toBeNull();
  });
});

describe("calculateZScore", () => {
  it("has no score until the window is full", () => {
    const values = Array.from({ length: 5 }, (_, i) => i);
    expect(calculateZScore(values, 3).slice(0, 3)).toEqual([null, null, null]);
  });

  it("scores an outlier against the preceding window", () => {
    const values = [...Array.from({ length: 20 }, () => 100), 130];
    // Baseline is flat at 100, so dispersion is zero and no z-score exists.
    expect(calculateZScore(values, 20)[20]).toBeNull();
  });

  it("measures deviation in standard deviations", () => {
    const baseline = [98, 102, 99, 101, 100, 97, 103, 100, 99, 101];
    const std = standardDeviation(baseline)!;
    const values = [...baseline, 100 + 3 * std];
    const scores = calculateZScore(values, 10);
    expect(scores[10]).toBeCloseTo(3, 1);
  });

  it("returns null when the window contains gaps", () => {
    const values: (number | null)[] = [1, 2, null, 4, 5, 6];
    expect(calculateZScore(values, 3)[4]).toBeNull();
  });

  it("returns an empty array for empty input", () => {
    expect(calculateZScore([], 20)).toEqual([]);
  });

  it("rejects a window that cannot produce dispersion", () => {
    expect(() => calculateZScore([1, 2, 3], 1)).toThrow();
  });
});

describe("calculateVolumeZScore", () => {
  it("flags a volume spike above its own baseline", () => {
    const baseline = Array.from({ length: 20 }, (_, i) => 10_000 + (i % 5) * 400);
    const scores = calculateVolumeZScore([...baseline, 40_000], 20);
    expect(scores[20]!).toBeGreaterThan(3);
  });

  it("returns null for a perfectly flat volume history", () => {
    const flat = Array.from({ length: 21 }, () => 5_000);
    expect(calculateVolumeZScore(flat, 20)[20]).toBeNull();
  });
});

describe("calculateSignalScore", () => {
  it("is zero when neither leg is measurable", () => {
    expect(calculateSignalScore(null, null)).toBe(0);
  });

  it("saturates at 100", () => {
    expect(calculateSignalScore(12, 40)).toBe(100);
  });

  it("caps each leg at 50", () => {
    expect(calculateSignalScore(null, 9)).toBe(50);
  });

  it("treats price direction symmetrically", () => {
    expect(calculateSignalScore(-3.4, 4.1)).toBe(calculateSignalScore(3.4, 4.1));
  });

  it("scores a 3.4 / 4.1 observation in the low 80s", () => {
    expect(calculateSignalScore(3.4, 4.1)).toBeCloseTo(75, 0);
  });
});

describe("classifySignal", () => {
  it("identifies a combined anomaly", () => {
    expect(classifySignal(3.4, 4.1)).toBe("PRICE_VOLUME_ANOMALY");
  });

  it("identifies a volume-only anomaly", () => {
    expect(classifySignal(0.4, 3.2)).toBe("UNUSUAL_VOLUME");
  });

  it("identifies a price-only anomaly in either direction", () => {
    expect(classifySignal(-3.5, 0.2)).toBe("UNUSUAL_PRICE");
  });

  it("does not flag unusually low volume", () => {
    expect(classifySignal(0.1, -4.5)).toBeNull();
  });

  it("returns null when nothing crosses the threshold", () => {
    expect(classifySignal(1.2, 2.9)).toBeNull();
  });

  it("honours custom thresholds", () => {
    expect(classifySignal(2.1, 0.1, 2, 3)).toBe("UNUSUAL_PRICE");
  });
});

describe("analyseBars", () => {
  it("handles an empty series", () => {
    expect(analyseBars([])).toEqual({ bars: [], signals: [] });
  });

  it("sorts unordered input by timestamp", () => {
    const result = analyseBars([
      bar("2026-02-02T00:00:00Z", 101, 10),
      bar("2026-02-01T00:00:00Z", 100, 10),
    ]);
    expect(result.bars.map((b) => b.timestamp)).toEqual([
      "2026-02-01T00:00:00Z",
      "2026-02-02T00:00:00Z",
    ]);
  });

  it("produces no signals when there is less history than the window", () => {
    const bars = Array.from({ length: 5 }, (_, i) =>
      bar(`2026-03-0${i + 1}T00:00:00Z`, 100 + i, 1000 + i),
    );
    expect(analyseBars(bars, { window: 20 }).signals).toHaveLength(0);
  });

  it("flags an injected price and volume shock", () => {
    const bars: MarketBar[] = [];
    let close = 100;
    for (let i = 0; i < 40; i += 1) {
      close *= 1 + (i % 2 === 0 ? 0.001 : -0.0008);
      bars.push(
        bar(new Date(Date.UTC(2026, 0, 1) + i * 3_600_000).toISOString(), close, 10_000 + (i % 4) * 300),
      );
    }
    bars.push(bar(new Date(Date.UTC(2026, 0, 1) + 40 * 3_600_000).toISOString(), close * 1.05, 90_000));

    const { signals } = analyseBars(bars, { window: 20 });
    expect(signals).toHaveLength(1);
    expect(signals[0].type).toBe("PRICE_VOLUME_ANOMALY");
    expect(signals[0].score).toBeGreaterThan(70);
  });
});

describe("summariseSignals", () => {
  it("reports an empty summary for no signals", () => {
    expect(summariseSignals([])).toEqual({
      signalCount: 0,
      highScoreCount: 0,
      averageScore: null,
      latestSignal: null,
      maxScore: null,
    });
  });

  it("picks the most recent signal by timestamp", () => {
    const summary = summariseSignals([
      {
        timestamp: "2026-01-02T00:00:00Z",
        type: "UNUSUAL_VOLUME",
        score: 55,
        priceZScore: 1,
        volumeZScore: 3.2,
        close: 100,
        volume: 1,
        description: "",
      },
      {
        timestamp: "2026-01-09T00:00:00Z",
        type: "UNUSUAL_PRICE",
        score: 85,
        priceZScore: 3.9,
        volumeZScore: 1,
        close: 100,
        volume: 1,
        description: "",
      },
    ]);
    expect(summary.latestSignal?.timestamp).toBe("2026-01-09T00:00:00Z");
    expect(summary.highScoreCount).toBe(1);
    expect(summary.averageScore).toBe(70);
  });
});

describe("calculateNetPosition", () => {
  it("subtracts short from long", () => {
    expect(calculateNetPosition(180_000, 150_000)).toBe(30_000);
  });

  it("returns null for missing legs", () => {
    expect(calculateNetPosition(null, 100)).toBeNull();
    expect(calculateNetPosition(100, undefined)).toBeNull();
  });
});

describe("withWeeklyChanges", () => {
  const observation = (
    reportDate: string,
    speculativeNet: number,
  ): CotObservation => ({
    reportDate,
    openInterest: 1_000_000,
    speculativeLong: speculativeNet + 100_000,
    speculativeShort: 100_000,
    speculativeNet,
    hedgerLong: 0,
    hedgerShort: 0,
    hedgerNet: 0,
  });

  it("leaves the first week without a change", () => {
    const result = withWeeklyChanges([observation("2026-01-06", 10_000)]);
    expect(result[0].speculativeNetChange).toBeUndefined();
  });

  it("computes week-over-week changes in date order", () => {
    const result = withWeeklyChanges([
      observation("2026-01-13", 14_000),
      observation("2026-01-06", 10_000),
    ]);
    expect(result.map((o) => o.reportDate)).toEqual(["2026-01-06", "2026-01-13"]);
    expect(result[1].speculativeNetChange).toBe(4_000);
  });

  it("drops malformed records rather than guessing", () => {
    const malformed = { ...observation("2026-01-06", 1), reportDate: "" };
    expect(withWeeklyChanges([malformed])).toHaveLength(0);
  });

  it("handles an empty report list", () => {
    expect(withWeeklyChanges([])).toEqual([]);
  });
});
