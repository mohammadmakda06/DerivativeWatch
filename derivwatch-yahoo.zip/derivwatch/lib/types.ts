export type SignalType =
  | "UNUSUAL_VOLUME"
  | "UNUSUAL_PRICE"
  | "PRICE_VOLUME_ANOMALY";

export type MarketBar = {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  /** Return from the previous close, as a decimal (0.004 = +0.4%). */
  return?: number;
  priceZScore?: number;
  volumeZScore?: number;
  /** Rolling standard deviation of returns over the baseline window. */
  volatility?: number;
  signalScore?: number;
  signalType?: SignalType;
};

/**
 * The subset of a bar the charts actually render. Market pages send this to
 * the client instead of the full OHLCV record, which keeps the payload for a
 * 1,200-observation series well under a hundred kilobytes.
 */
export type ChartBar = Pick<
  MarketBar,
  "timestamp" | "close" | "volume" | "priceZScore" | "volumeZScore" | "signalType"
>;

export type SurveillanceSignal = {
  timestamp: string;
  type: SignalType;
  score: number;
  priceZScore: number;
  volumeZScore: number;
  close: number;
  volume: number;
  description: string;
};

export type ContractMeta = {
  symbol: string;
  name: string;
  assetClass: string;
  exchange: string;
  /** Provider symbol for the continuous front-month series, e.g. "ES=F". */
  sourceSymbol: string;
  /** Price decimals used for display. */
  priceDecimals: number;
  cot: CotContractConfig;
};

/**
 * ES and NQ are published in the Traders in Financial Futures report;
 * CL and GC in the Disaggregated report. The trader categories differ, so
 * each contract carries the labels that actually apply to it.
 */
export type CotReport = "tff" | "disaggregated";

export type CotContractConfig = {
  report: CotReport;
  /** CFTC contract market code, e.g. "13874A" for the E-mini S&P 500. */
  contractCode: string;
  /** Category treated as speculative positioning in this report. */
  speculativeLabel: string;
  /** Category treated as hedging/intermediary positioning in this report. */
  hedgerLabel: string;
};

export type CotObservation = {
  reportDate: string;
  openInterest: number;
  speculativeLong: number;
  speculativeShort: number;
  speculativeNet: number;
  hedgerLong: number;
  hedgerShort: number;
  hedgerNet: number;
  /** Week-over-week change in the speculative net position. */
  speculativeNetChange?: number;
  hedgerNetChange?: number;
  openInterestChange?: number;
};

export type CotSeries = {
  symbol: string;
  report: CotReport;
  reportName: string;
  contractCode: string;
  marketName: string;
  speculativeLabel: string;
  hedgerLabel: string;
  observations: CotObservation[];
};

export type SurveillanceSummary = {
  signalCount: number;
  highScoreCount: number;
  averageScore: number | null;
  latestSignal: SurveillanceSignal | null;
  maxScore: number | null;
};

export type MarketDataset = {
  contract: {
    symbol: string;
    name: string;
    assetClass: string;
    exchange: string;
    sourceSymbol: string;
  };
  meta: {
    source: string;
    dataset: string;
    schema: string;
    start: string;
    end: string;
    generatedAt: string;
    window: number;
    volumeThreshold: number;
    priceThreshold: number;
    /** True when the file was produced by make-fixtures, not by a real source. */
    isFixture: boolean;
  };
  stats: {
    barCount: number;
    latestClose: number | null;
    latestChange: number | null;
    latestVolume: number | null;
    latestVolatility: number | null;
    latestTimestamp: string | null;
  };
  summary: SurveillanceSummary;
  bars: MarketBar[];
  signals: SurveillanceSignal[];
};

export type CotDataset = {
  meta: {
    source: string;
    intermediary: string | null;
    endpoint: string;
    generatedAt: string;
    isFixture: boolean;
  };
  series: Record<string, CotSeries>;
};
