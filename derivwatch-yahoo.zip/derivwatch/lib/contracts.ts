import type { ContractMeta } from "./types";

/**
 * The four contracts DerivWatch covers.
 *
 * `sourceSymbol` is Yahoo Finance's continuous front-month futures series for
 * each root - the `=F` suffix. That series already rolls with the front
 * contract, which is what volume-based signals need: a fixed-expiry series
 * would put an artificial volume cliff in the baseline once liquidity rolled
 * away from it.
 *
 * `cot.contractCode` is the CFTC contract market code. To confirm one against
 * the source before a full run:
 *   python scripts/fetch_cot_data.py --inspect GOLD
 */
export const contracts: Record<string, ContractMeta> = {
  ES: {
    symbol: "ES",
    name: "E-mini S&P 500",
    assetClass: "Equity Index",
    exchange: "CME",
    sourceSymbol: "ES=F",
    priceDecimals: 2,
    cot: {
      report: "tff",
      contractCode: "13874A",
      speculativeLabel: "Leveraged Funds",
      hedgerLabel: "Dealer / Intermediary",
    },
  },
  NQ: {
    symbol: "NQ",
    name: "E-mini Nasdaq-100",
    assetClass: "Equity Index",
    exchange: "CME",
    sourceSymbol: "NQ=F",
    priceDecimals: 2,
    cot: {
      report: "tff",
      contractCode: "209742",
      speculativeLabel: "Leveraged Funds",
      hedgerLabel: "Dealer / Intermediary",
    },
  },
  CL: {
    symbol: "CL",
    name: "WTI Crude Oil",
    assetClass: "Energy",
    exchange: "NYMEX",
    sourceSymbol: "CL=F",
    priceDecimals: 2,
    cot: {
      report: "disaggregated",
      contractCode: "067651",
      speculativeLabel: "Managed Money",
      hedgerLabel: "Producer / Merchant",
    },
  },
  GC: {
    symbol: "GC",
    name: "Gold",
    assetClass: "Metals",
    exchange: "COMEX",
    sourceSymbol: "GC=F",
    priceDecimals: 2,
    cot: {
      report: "disaggregated",
      contractCode: "088691",
      speculativeLabel: "Managed Money",
      hedgerLabel: "Producer / Merchant",
    },
  },
};

export const contractList: ContractMeta[] = Object.values(contracts);

export const contractSymbols: string[] = Object.keys(contracts);

export function getContract(symbol: string): ContractMeta | undefined {
  return contracts[symbol.toUpperCase()];
}

export const reportNames: Record<string, string> = {
  tff: "Traders in Financial Futures (futures only)",
  disaggregated: "Disaggregated (futures only)",
};
