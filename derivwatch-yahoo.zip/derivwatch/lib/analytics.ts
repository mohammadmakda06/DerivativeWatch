import type {
  CotObservation,
  MarketBar,
  SignalType,
  SurveillanceSignal,
  SurveillanceSummary,
} from "./types";

export const DEFAULT_WINDOW = 20;
export const DEFAULT_VOLUME_Z_THRESHOLD = 3;
export const DEFAULT_PRICE_Z_THRESHOLD = 3;

/**
 * Every function here is deterministic and side-effect free. Missing or
 * undefined values are represented as `null` rather than silently coerced to
 * zero, because a zero z-score means "exactly average", which is a very
 * different claim from "not enough history yet".
 */

export function mean(values: number[]): number | null {
  if (values.length === 0) return null;
  let total = 0;
  for (const value of values) total += value;
  return total / values.length;
}

/** Sample standard deviation (n - 1), matching pandas' rolling().std(). */
export function standardDeviation(values: number[]): number | null {
  if (values.length < 2) return null;
  const avg = mean(values);
  if (avg === null) return null;
  let sum = 0;
  for (const value of values) sum += (value - avg) ** 2;
  return Math.sqrt(sum / (values.length - 1));
}

/**
 * Simple returns from a close series: close[i] / close[i - 1] - 1.
 * The first element has no predecessor, so it is null. A zero or negative
 * previous close cannot produce a meaningful return and is also null.
 */
export function calculateReturns(closes: number[]): (number | null)[] {
  return closes.map((close, index) => {
    if (index === 0) return null;
    const previous = closes[index - 1];
    if (!isFiniteNumber(previous) || !isFiniteNumber(close) || previous <= 0) {
      return null;
    }
    return close / previous - 1;
  });
}

/**
 * Rolling z-score of a series against the `window` observations that precede
 * each point. The current observation is excluded from its own baseline, so a
 * single large print cannot inflate the mean it is being compared against.
 *
 * Returns null where there is insufficient history, where the window contains
 * non-numeric values, or where the window's standard deviation is zero.
 */
export function calculateZScore(
  values: (number | null)[],
  window: number = DEFAULT_WINDOW,
): (number | null)[] {
  if (window < 2) {
    throw new Error("Rolling window must cover at least 2 observations");
  }

  return values.map((value, index) => {
    if (!isFiniteNumber(value)) return null;
    if (index < window) return null;

    const baseline = values.slice(index - window, index);
    if (!baseline.every(isFiniteNumber)) return null;

    const baselineMean = mean(baseline as number[]);
    const baselineStd = standardDeviation(baseline as number[]);
    if (baselineMean === null || baselineStd === null) return null;
    // A flat window has no dispersion, so no deviation is measurable.
    if (baselineStd === 0) return null;

    return (value - baselineMean) / baselineStd;
  });
}

export function calculateVolumeZScore(
  volumes: number[],
  window: number = DEFAULT_WINDOW,
): (number | null)[] {
  return calculateZScore(volumes, window);
}

/** Rolling standard deviation of returns, a plain realised-volatility proxy. */
export function calculateRollingVolatility(
  returns: (number | null)[],
  window: number = DEFAULT_WINDOW,
): (number | null)[] {
  return returns.map((_, index) => {
    if (index < window) return null;
    const baseline = returns.slice(index - window, index);
    if (!baseline.every(isFiniteNumber)) return null;
    return standardDeviation(baseline as number[]);
  });
}

/**
 * Surveillance Signal Score, 0-100.
 *
 * Each leg contributes up to 50 points and saturates at 5 standard deviations,
 * so a 12-sigma volume print and an 8-sigma one both score 50 on that leg. The
 * score measures how unusual an observation is relative to its own recent
 * baseline. It is not a probability of anything.
 */
export function calculateSignalScore(
  priceZScore: number | null,
  volumeZScore: number | null,
): number {
  const priceComponent = componentScore(priceZScore);
  const volumeComponent = componentScore(volumeZScore);
  return round(priceComponent + volumeComponent, 1);
}

function componentScore(zScore: number | null): number {
  if (!isFiniteNumber(zScore)) return 0;
  return Math.min(Math.abs(zScore) / 5, 1) * 50;
}

export function classifySignal(
  priceZScore: number | null,
  volumeZScore: number | null,
  priceThreshold: number = DEFAULT_PRICE_Z_THRESHOLD,
  volumeThreshold: number = DEFAULT_VOLUME_Z_THRESHOLD,
): SignalType | null {
  const priceFlag =
    isFiniteNumber(priceZScore) && Math.abs(priceZScore) >= priceThreshold;
  // Volume is one-sided: unusually *low* volume is not what this flags.
  const volumeFlag = isFiniteNumber(volumeZScore) && volumeZScore >= volumeThreshold;

  if (priceFlag && volumeFlag) return "PRICE_VOLUME_ANOMALY";
  if (volumeFlag) return "UNUSUAL_VOLUME";
  if (priceFlag) return "UNUSUAL_PRICE";
  return null;
}

export function describeSignal(
  type: SignalType,
  priceZScore: number | null,
  volumeZScore: number | null,
): string {
  const priceText = isFiniteNumber(priceZScore)
    ? `${priceZScore > 0 ? "higher" : "lower"} than the recent baseline`
    : "not measurable";

  switch (type) {
    case "PRICE_VOLUME_ANOMALY":
      return `Price movement and trading volume were both well outside their recent historical baselines. The move was ${priceText}, alongside volume ${formatZ(volumeZScore)} standard deviations above its own baseline.`;
    case "UNUSUAL_VOLUME":
      return `Trading volume was ${formatZ(volumeZScore)} standard deviations above its recent baseline, without a comparable move in price.`;
    case "UNUSUAL_PRICE":
      return `Price moved ${formatZ(priceZScore)} standard deviations from its recent baseline, on volume within the normal range.`;
  }
}

function formatZ(value: number | null): string {
  return isFiniteNumber(value) ? Math.abs(value).toFixed(1) : "an unknown number of";
}

export type AnalyseOptions = {
  window?: number;
  priceThreshold?: number;
  volumeThreshold?: number;
};

export type AnalyseResult = {
  bars: MarketBar[];
  signals: SurveillanceSignal[];
};

/**
 * Enrich raw OHLCV bars with returns, rolling z-scores, volatility and signal
 * classifications, and extract the flagged observations.
 */
export function analyseBars(
  rawBars: MarketBar[],
  options: AnalyseOptions = {},
): AnalyseResult {
  const window = options.window ?? DEFAULT_WINDOW;
  const priceThreshold = options.priceThreshold ?? DEFAULT_PRICE_Z_THRESHOLD;
  const volumeThreshold = options.volumeThreshold ?? DEFAULT_VOLUME_Z_THRESHOLD;

  if (rawBars.length === 0) return { bars: [], signals: [] };

  const sorted = [...rawBars].sort((a, b) =>
    a.timestamp < b.timestamp ? -1 : a.timestamp > b.timestamp ? 1 : 0,
  );

  const closes = sorted.map((bar) => bar.close);
  const volumes = sorted.map((bar) => bar.volume);

  const returns = calculateReturns(closes);
  const priceZScores = calculateZScore(returns, window);
  const volumeZScores = calculateVolumeZScore(volumes, window);
  const volatility = calculateRollingVolatility(returns, window);

  const signals: SurveillanceSignal[] = [];

  const bars = sorted.map((bar, index) => {
    const priceZ = priceZScores[index];
    const volumeZ = volumeZScores[index];
    const type = classifySignal(priceZ, volumeZ, priceThreshold, volumeThreshold);
    const score = calculateSignalScore(priceZ, volumeZ);

    if (type) {
      signals.push({
        timestamp: bar.timestamp,
        type,
        score,
        priceZScore: round(priceZ ?? 0, 2),
        volumeZScore: round(volumeZ ?? 0, 2),
        close: bar.close,
        volume: bar.volume,
        description: describeSignal(type, priceZ, volumeZ),
      });
    }

    return {
      ...bar,
      return: nullableRound(returns[index], 6),
      priceZScore: nullableRound(priceZ, 2),
      volumeZScore: nullableRound(volumeZ, 2),
      volatility: nullableRound(volatility[index], 6),
      signalScore: type ? score : undefined,
      signalType: type ?? undefined,
    } satisfies MarketBar;
  });

  return { bars, signals };
}

export function summariseSignals(
  signals: SurveillanceSignal[],
  highScoreThreshold = 70,
): SurveillanceSummary {
  if (signals.length === 0) {
    return {
      signalCount: 0,
      highScoreCount: 0,
      averageScore: null,
      latestSignal: null,
      maxScore: null,
    };
  }

  const scores = signals.map((signal) => signal.score);
  const latest = signals.reduce((newest, signal) =>
    signal.timestamp > newest.timestamp ? signal : newest,
  );

  return {
    signalCount: signals.length,
    highScoreCount: signals.filter((s) => s.score >= highScoreThreshold).length,
    averageScore: round(mean(scores) ?? 0, 1),
    latestSignal: latest,
    maxScore: Math.max(...scores),
  };
}

/* ------------------------------------------------------------------ */
/* CFTC positioning                                                    */
/* ------------------------------------------------------------------ */

export function calculateNetPosition(
  long: number | null | undefined,
  short: number | null | undefined,
): number | null {
  if (!isFiniteNumber(long) || !isFiniteNumber(short)) return null;
  return long - short;
}

/**
 * Add week-over-week changes to a COT series. Input may arrive in any order and
 * may contain malformed records; those are dropped rather than guessed at.
 */
export function withWeeklyChanges(
  observations: CotObservation[],
): CotObservation[] {
  const clean = observations
    .filter((o) => typeof o.reportDate === "string" && o.reportDate.length > 0)
    .sort((a, b) => (a.reportDate < b.reportDate ? -1 : 1));

  return clean.map((observation, index) => {
    if (index === 0) return { ...observation };
    const previous = clean[index - 1];
    return {
      ...observation,
      speculativeNetChange: diff(observation.speculativeNet, previous.speculativeNet),
      hedgerNetChange: diff(observation.hedgerNet, previous.hedgerNet),
      openInterestChange: diff(observation.openInterest, previous.openInterest),
    };
  });
}

function diff(current: number, previous: number): number | undefined {
  if (!isFiniteNumber(current) || !isFiniteNumber(previous)) return undefined;
  return current - previous;
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

export function round(value: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

export function nullableRound(
  value: number | null | undefined,
  decimals: number,
): number | undefined {
  if (!isFiniteNumber(value)) return undefined;
  return round(value, decimals);
}
