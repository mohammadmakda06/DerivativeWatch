import { promises as fs } from "node:fs";
import path from "node:path";

import { contractList } from "./contracts";
import type { CotDataset, CotSeries, MarketDataset } from "./types";

const DATA_DIR = path.join(process.cwd(), "data");

/**
 * Datasets are read on the server at render time. A missing file is a normal
 * state before the ingestion scripts have been run, so it resolves to null and
 * the UI says so rather than inventing prices.
 */
async function readJson<T>(filename: string): Promise<T | null> {
  try {
    const raw = await fs.readFile(path.join(DATA_DIR, filename), "utf8");
    return JSON.parse(raw) as T;
  } catch (error) {
    const code = (error as NodeJS.ErrnoException)?.code;
    if (code === "ENOENT") return null;
    console.error(`Failed to read data/${filename}:`, error);
    return null;
  }
}

export async function getMarketDataset(
  symbol: string,
): Promise<MarketDataset | null> {
  return readJson<MarketDataset>(`${symbol.toUpperCase()}.json`);
}

export async function getAllMarketDatasets(): Promise<
  { symbol: string; dataset: MarketDataset | null }[]
> {
  return Promise.all(
    contractList.map(async (contract) => ({
      symbol: contract.symbol,
      dataset: await getMarketDataset(contract.symbol),
    })),
  );
}

export async function getCotDataset(): Promise<CotDataset | null> {
  return readJson<CotDataset>("COT.json");
}

export async function getCotSeries(symbol: string): Promise<CotSeries | null> {
  const cot = await getCotDataset();
  return cot?.series?.[symbol.toUpperCase()] ?? null;
}

/** The most statistically unusual signal across every loaded market. */
export async function getFeaturedSignal() {
  const datasets = await getAllMarketDatasets();

  let featured: {
    symbol: string;
    name: string;
    dataset: MarketDataset;
    signal: NonNullable<MarketDataset["summary"]["latestSignal"]>;
  } | null = null;

  for (const { symbol, dataset } of datasets) {
    if (!dataset) continue;
    for (const signal of dataset.signals) {
      const beatsScore = !featured || signal.score > featured.signal.score;
      const tiesButNewer =
        featured !== null &&
        signal.score === featured.signal.score &&
        signal.timestamp > featured.signal.timestamp;
      if (beatsScore || tiesButNewer) {
        featured = { symbol, name: dataset.contract.name, dataset, signal };
      }
    }
  }

  return featured;
}

/** Whole days since the newest observation across all markets. */
export function daysSince(timestamp: string | null | undefined): number | null {
  if (!timestamp) return null;
  const then = Date.parse(timestamp);
  if (Number.isNaN(then)) return null;
  return Math.floor((Date.now() - then) / 86_400_000);
}
