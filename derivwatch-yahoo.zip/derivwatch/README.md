# DerivWatch

**Finding unusual activity in futures markets.**

DerivWatch explores real futures market data and CFTC positioning data to
highlight statistically unusual market activity. It covers four contracts — ES,
NQ, CL and GC — and for each one shows historical price and volume, the
observations that fell outside their own recent statistical baseline, and the
weekly CFTC positioning behind that market.

The site is a small Next.js application reading pre-processed JSON. There is no
database, no login and no backend service.

---

## Why I built it

I wanted to build a small project at the intersection of software engineering,
data analytics and derivatives markets. The project was inspired by researching
how derivatives-market organizations use market data and surveillance
technology: they start from ordinary market observations, compare them with a
baseline, and surface the ones worth a human look. That pipeline is small enough
to build properly and interesting enough to be worth building.

---

## Tech stack

| Layer | Tools |
| --- | --- |
| Website | Next.js (App Router), TypeScript, Tailwind CSS, Recharts |
| Analytics | TypeScript (`lib/analytics.ts`), unit tested with Vitest |
| Ingestion | Python, yfinance, pandas |
| Data | Yahoo Finance historical futures, CFTC Commitments of Traders |

---

## Data sources

**Market data — Yahoo Finance.** Historical futures observations from Yahoo's
continuous front-month series (`ES=F`, `NQ=F`, `CL=F`, `GC=F`), at a 1-hour
interval by default. A continuous series is the right choice for volume-based
signals, because a fixed-expiry series stays on a contract after liquidity has
rolled away from it, putting an artificial volume cliff in the baseline.

Yahoo has no official public data API; this uses the endpoints its own site
calls, through the [yfinance](https://github.com/ranaroussi/yfinance) library.
That is normal for a research project and the site says so on the methodology
page rather than implying a vendor relationship. Two practical consequences:
intraday intervals only reach back roughly 60 days, and volume occasionally
arrives incomplete — bars reporting zero volume are dropped during ingestion so
they cannot distort the rolling baseline.

**Positioning — CFTC Commitments of Traders.** Retrieved directly from the
CFTC's own Public Reporting Environment (`publicreporting.cftc.gov`), a Socrata
API. No key required. Two reports are used, because the trader categories
differ by market:

| Contracts | Report | Categories shown |
| --- | --- | --- |
| ES, NQ | Traders in Financial Futures (futures only) | Leveraged Funds, Dealer / Intermediary |
| CL, GC | Disaggregated (futures only) | Managed Money, Producer / Merchant |

`COT_API_BASE_URL` can be pointed at an intermediary API instead. If you do
that, set `intermediary` in the raw payload — the UI credits the CFTC as the
source of the data and names the intermediary separately, rather than presenting
an intermediary as the CFTC.

Data is historical, not live, and the site says so. The latest observation
timestamp is shown on every page that displays it.

---

## Architecture

```
Yahoo Finance                 CFTC COT
    |                             |
    v                             v
scripts/fetch_market_data.py   scripts/fetch_cot_data.py
    |                             |
    +------------> data/raw/ <----+
                       |
                       v
             scripts/build-data.ts        (lib/analytics.ts)
                       |
                       v
       data/ES.json  NQ.json  CL.json  GC.json  COT.json
                       |
                       v
                    Next.js  (server components read the JSON)
                       |
                       v
               Interactive website
```

Ingestion runs locally or on a schedule; the website only ever reads committed
JSON. That keeps data fetching out of the browser, out of the build and
out of the deployment, and makes the site deployable to Vercel as a static-ish
Next.js app with no secrets at all. No API key or account is needed anywhere in
this project.

Statistics live in `lib/analytics.ts`, which both the build script and the test
suite import, so the numbers on the site cannot drift away from the numbers
under test.

```
app/                 pages: /, /markets, /markets/[symbol], /methodology
components/          Header, MarketCard, PriceChart, VolumeChart, SignalCard,
                     SignalTable, CotPositioning, DataSourceCard, ...
lib/                 contracts, types, analytics, data loading, formatting
scripts/             ingestion (Python) and the processing step (TypeScript)
data/                processed JSON consumed by the site
tests/               unit tests for the analytics
```

---

## Analytics

Each observation is compared with the **20 observations immediately before it**,
excluding itself — otherwise a large print inflates the mean it is being
measured against.

```
return   = close / previous_close - 1
z        = (x - rolling_mean) / rolling_standard_deviation
```

Three signals:

| Signal | Rule |
| --- | --- |
| `UNUSUAL_VOLUME` | `volume_z >= 3` |
| `UNUSUAL_PRICE` | `abs(price_z) >= 3` |
| `PRICE_VOLUME_ANOMALY` | both, on the same observation |

Price is two-sided; volume is one-sided, since unusually quiet trading is not
what this looks for. All thresholds and the window length are configurable
through environment variables.

Each flagged observation gets a **Surveillance Signal Score** from 0 to 100:

```
price_component  = min(abs(price_z)  / 5, 1) * 50
volume_component = min(abs(volume_z) / 5, 1) * 50
score            = price_component + volume_component
```

A higher score indicates that the observed market activity is more unusual
relative to the historical baseline used by DerivWatch.

Positioning is kept deliberately simple — net position per category, plus
week-over-week change:

```
net = long - short
```

No machine learning is used anywhere. Every number can be reproduced by hand
from the underlying bars.

---

## Limitations

DerivWatch identifies statistically unusual market activity. **It does not
determine whether manipulation, misconduct, or another regulatory violation
occurred.**

- Public market data shows what happened, not who did it or why.
- CFTC positioning is aggregated by category and published weekly with a lag, so
  it cannot be tied to any individual observation.
- Anomalies routinely have legitimate explanations: economic releases, contract
  rolls, index rebalancing, settlement windows, thin overnight liquidity.
- A signal is a starting point for human review, not a conclusion.
- The score measures distance from a baseline. It is not a probability of
  wrongdoing.

---

## Running locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

The site runs immediately, with honest empty states in place of data.

### Generating data

**Real data** (ingestion needs Python; the website does not):

```bash
python3 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r scripts/requirements.txt

# Confirm the symbols resolve before a full run
python scripts/fetch_market_data.py --check

python scripts/fetch_market_data.py     # -> data/raw/*.bars.json
python scripts/fetch_cot_data.py        # -> data/raw/cot.json
npm run data:build                      # -> data/ES.json, ..., data/COT.json
```

```
Fetching ES (ES=F, 1h)...
  downloaded 1,483 observations
  saved data/raw/ES.bars.json
...
ES: 1,483 observations, 26 signals (4 price+volume), saved data/ES.json
```

If a CFTC contract code ever needs checking:

```bash
python scripts/fetch_cot_data.py --inspect GOLD
```

**Without fetching anything**, generate clearly-labelled synthetic fixtures:

```bash
npm run data:fixtures && npm run data:build
```

Fixture series start from an arbitrary level of 1,000 and carry
`isFixture: true`, which the site surfaces as a banner on every page that shows
them. They exist for UI development and are never presented as market data.

### Tests and checks

```bash
npm test        # analytics unit tests
npm run typecheck
npm run lint
```

Tests cover returns, rolling z-scores, the signal score, classification and net
positioning, plus the edge cases that matter: empty series, insufficient
history, gaps in the window, a zero standard deviation and malformed CFTC rows.

---

## Deployment

```
local / scheduled ingestion  ->  processed JSON  ->  git  ->  Vercel
```

Commit `data/*.json` and deploy. The deployed site needs no environment
variables, no API key and no account; `.env`, `.env.local` and `data/raw/` are
gitignored. Refreshing the data means re-running ingestion and pushing the
regenerated JSON.

---

## Configuration

| Variable | Purpose |
| --- | --- |
| `MARKET_DATA_INTERVAL` | Bar size, default `1h` (`1d` for a longer history) |
| `MARKET_DATA_START_DATE` / `MARKET_DATA_END_DATE` | Ingestion window, UTC; blank start takes the maximum the interval allows |
| `COT_API_BASE_URL` | Default `https://publicreporting.cftc.gov/resource` |
| `COT_TFF_DATASET` / `COT_DISAGGREGATED_DATASET` | Socrata dataset identifiers |
| `COT_WEEKS` | Weekly reports to retrieve, default 52 |
| `SURVEILLANCE_WINDOW` | Rolling baseline length, default 20 |
| `SURVEILLANCE_VOLUME_Z_THRESHOLD` | Default 3 |
| `SURVEILLANCE_PRICE_Z_THRESHOLD` | Default 3 |
