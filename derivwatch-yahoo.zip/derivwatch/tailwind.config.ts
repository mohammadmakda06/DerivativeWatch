import type { Config } from "tailwindcss";

/**
 * Palette notes
 * -------------
 * ink/panel/rule build a charcoal-navy research surface; accent is a
 * restrained slate blue used only for interactive affordances. `signal`
 * (amber) marks statistically unusual observations - deliberately not red,
 * because a flag is not an allegation.
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0A0D12",
        panel: "#0F141B",
        raised: "#141A23",
        rule: "#1D2633",
        text: "#E8EBF0",
        muted: "#8B96A8",
        faint: "#5F6B7D",
        accent: "#5B8DEF",
        signal: "#D9A441",
        up: "#3FA46A",
        down: "#C9566B",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      fontSize: {
        micro: ["0.6875rem", { lineHeight: "1rem", letterSpacing: "0.02em" }],
      },
      maxWidth: {
        shell: "78rem",
      },
    },
  },
  plugins: [],
};

export default config;
