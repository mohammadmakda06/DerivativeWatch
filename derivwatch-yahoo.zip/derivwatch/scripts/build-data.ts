/**
 * Turn raw ingestion output into the compact datasets the website reads.
 *
 *   data/raw/ES.bars.json  ->  data/ES.json
 *   data/raw/cot.json      ->  data/COT.json
 *
 * All statistics come from lib/analytics.ts, which is unit tested, so the
 * numbers on the site and the numbers in the tests cannot drift apart.
 *
 *   npm run data:build
 */
import { promises as fs, readFileSync } from "node:fs";
import path from "node:path";

import {
  analyseBars,
  calculateNetPosition,
  summariseSignals,
  withWeeklyChanges,
  DEFAULT_PRICE_Z_THRESHOLD,
  DEFAULT_VOLUME_Z_THRESHOLD,
  DEFAULT_WINDOW,
} from "../lib/analytics";
import { contractList, reportNames } from "../lib/contracts";
import type {
  CotDataset,
  CotObservation,
  MarketBar,
  MarketDataset,
} from "../lib/types";

const ROOT = process.cwd();

/** Minimal .env reader: tsx does not load them the way `next dev` does. */
function loadEnv() {
  for (const name of [".env.local", ".env"]) {
    let contents: string;
    try {
      contents = readFileSync(path.join(ROOT, name), "utf8");
    } catch {
      continue;
    }
    for (const line of contents.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#") || !trimmed.includes("=")) continue;
      const [key, ...rest] = trimmed.split("=");
      if (process.env[key.trim()] === undefined) {
        process.env[key.trim()] = rest.join("=").trim();
      }
    }
  }
}

loadEnv();
const RAW_DIR = path.join(ROOT, "data", "raw");
const OUT_DIR = path.join(ROOT, "data");

type RawBars = {
  symbol: string;
  sourceSymbol: string;
  dataset: string;
  schema: string;
  start: string;
  end: string;
  source: string;
  isFixture?: boolean;
  bars: MarketBar[];
};

type RawCot = {
  source: string;
  endpoint: string;
  intermediary?: string | null;
  isFixture?: boolean;
  series: Record<
    string,
    {
      symbol: string;
      report: "tff" | "disaggregated";
      contractCode: string;
      marketName: string;
      observations: {
        reportDate: string;
        openInterest: number;
        speculativeLong: number;
        speculativeShort: number;
        hedgerLong: number;
        hedgerShort: number;
      }[];
    }
  >;
};

function envNumber(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

async function readRaw<T>(filename: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(path.join(RAW_DIR, filename), "utf8")) as T;
  } catch {
    return null;
  }
}

async function buildMarkets(): Promise<number> {
  const window = envNumber("SURVEILLANCE_WINDOW", DEFAULT_WINDOW);
  const volumeThreshold = envNumber(
    "SURVEILLANCE_VOLUME_Z_THRESHOLD",
    DEFAULT_VOLUME_Z_THRESHOLD,
  );
  const priceThreshold = envNumber(
    "SURVEILLANCE_PRICE_Z_THRESHOLD",
    DEFAULT_PRICE_Z_THRESHOLD,
  );

  let built = 0;

  for (const contract of contractList) {
    const raw = await readRaw<RawBars>(`${contract.symbol}.bars.json`);
    if (!raw || raw.bars.length === 0) {
      console.log(`${contract.symbol}: no raw bars found, skipping`);
      continue;
    }

    const { bars, signals } = analyseBars(raw.bars, {
      window,
      priceThreshold,
      volumeThreshold,
    });

    const last = bars[bars.length - 1];
    const dataset: MarketDataset = {
      contract: {
        symbol: contract.symbol,
        name: contract.name,
        assetClass: contract.assetClass,
        exchange: contract.exchange,
        sourceSymbol: raw.sourceSymbol ?? contract.sourceSymbol,
      },
      meta: {
        source: raw.source ?? "Yahoo Finance",
        dataset: raw.dataset,
        schema: raw.schema,
        start: raw.start,
        end: raw.end,
        generatedAt: new Date().toISOString(),
        window,
        volumeThreshold,
        priceThreshold,
        isFixture: raw.isFixture === true,
      },
      stats: {
        barCount: bars.length,
        latestClose: last?.close ?? null,
        latestChange: last?.return ?? null,
        latestVolume: last?.volume ?? null,
        latestVolatility: last?.volatility ?? null,
        latestTimestamp: last?.timestamp ?? null,
      },
      summary: summariseSignals(signals),
      bars,
      signals,
    };

    await fs.writeFile(
      path.join(OUT_DIR, `${contract.symbol}.json`),
      JSON.stringify(dataset),
    );

    const anomalies = signals.filter((s) => s.type === "PRICE_VOLUME_ANOMALY").length;
    console.log(
      `${contract.symbol}: ${bars.length.toLocaleString()} observations, ` +
        `${signals.length} signals (${anomalies} price+volume), ` +
        `saved data/${contract.symbol}.json`,
    );
    built += 1;
  }

  return built;
}

async function buildCot(): Promise<boolean> {
  const raw = await readRaw<RawCot>("cot.json");
  if (!raw) {
    console.log("COT: no raw file found, skipping");
    return false;
  }

  const series: CotDataset["series"] = {};

  for (const contract of contractList) {
    const entry = raw.series[contract.symbol];
    if (!entry) continue;

    const observations: CotObservation[] = entry.observations
      .map((row) => {
        const speculativeNet = calculateNetPosition(
          row.speculativeLong,
          row.speculativeShort,
        );
        const hedgerNet = calculateNetPosition(row.hedgerLong, row.hedgerShort);
        if (speculativeNet === null || hedgerNet === null) return null;
        return {
          reportDate: row.reportDate,
          openInterest: row.openInterest,
          speculativeLong: row.speculativeLong,
          speculativeShort: row.speculativeShort,
          speculativeNet,
          hedgerLong: row.hedgerLong,
          hedgerShort: row.hedgerShort,
          hedgerNet,
        } satisfies CotObservation;
      })
      .filter((row): row is CotObservation => row !== null);

    if (observations.length === 0) continue;

    series[contract.symbol] = {
      symbol: contract.symbol,
      report: entry.report,
      reportName: reportNames[entry.report],
      contractCode: entry.contractCode,
      marketName: entry.marketName,
      speculativeLabel: contract.cot.speculativeLabel,
      hedgerLabel: contract.cot.hedgerLabel,
      observations: withWeeklyChanges(observations),
    };

    console.log(
      `${contract.symbol} COT: ${observations.length} weekly reports, ` +
        `latest ${observations[observations.length - 1].reportDate}`,
    );
  }

  const dataset: CotDataset = {
    meta: {
      source: raw.source ?? "CFTC Commitments of Traders",
      intermediary: raw.intermediary ?? null,
      endpoint: raw.endpoint,
      generatedAt: new Date().toISOString(),
      isFixture: raw.isFixture === true,
    },
    series,
  };

  await fs.writeFile(path.join(OUT_DIR, "COT.json"), JSON.stringify(dataset));
  console.log("Saved data/COT.json");
  return true;
}

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true });
  const markets = await buildMarkets();
  const cot = await buildCot();

  if (markets === 0 && !cot) {
    console.log(
      "\nNothing to build. Run the ingestion scripts first:\n" +
        "  python scripts/fetch_market_data.py\n" +
        "  python scripts/fetch_cot_data.py\n" +
        "or generate clearly-labelled development fixtures:\n" +
        "  npm run data:fixtures",
    );
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
