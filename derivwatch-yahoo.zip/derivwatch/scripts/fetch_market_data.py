"""Fetch historical futures bars from Yahoo Finance into data/raw/.

Runs locally or on a schedule, never as part of the deployed website.

    python scripts/fetch_market_data.py           # all four contracts
    python scripts/fetch_market_data.py ES CL     # a subset
    python scripts/fetch_market_data.py --check   # verify symbols resolve

Output: data/raw/<SYMBOL>.bars.json - normalised OHLCV only. Analytics happen
in scripts/build-data.ts so the statistics stay in one place with their tests.

Source note: Yahoo publishes continuous front-month futures series (ES=F and
friends). There is no official public API; yfinance wraps the endpoints Yahoo's
own site uses, which is fine for a research project but is worth stating plainly
rather than dressing up as a vendor feed. Intraday intervals only reach back
about 60 days, which suits the 30-90 day window this project wants anyway.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

try:
    import yfinance as yf
except ImportError:  # pragma: no cover - dependency guidance
    sys.exit("yfinance is not installed. Run: pip install -r scripts/requirements.txt")

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"

# Kept in step with lib/contracts.ts. Yahoo's "=F" suffix denotes the
# continuous front-month futures series for a root.
SYMBOLS = {
    "ES": "ES=F",
    "NQ": "NQ=F",
    "CL": "CL=F",
    "GC": "GC=F",
}

# Yahoo serves intraday intervals only for roughly the trailing 60 days.
INTRADAY_INTERVALS = {"1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h"}
INTRADAY_MAX_DAYS = 59


def load_env() -> None:
    """Minimal .env reader so the script needs no extra dependency."""
    for name in (".env.local", ".env"):
        path = ROOT / name
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())


def resolve_window(interval: str) -> tuple[str, str]:
    """Start and end dates, clamped to what Yahoo will actually serve."""
    end_raw = os.environ.get("MARKET_DATA_END_DATE") or date.today().isoformat()
    start_raw = os.environ.get("MARKET_DATA_START_DATE")

    end = date.fromisoformat(end_raw)
    start = date.fromisoformat(start_raw) if start_raw else end - timedelta(days=59)

    if interval in INTRADAY_INTERVALS:
        earliest = date.today() - timedelta(days=INTRADAY_MAX_DAYS)
        if start < earliest:
            print(
                f"  note: {interval} data only reaches back ~{INTRADAY_MAX_DAYS} days; "
                f"start moved from {start} to {earliest}"
            )
            start = earliest

    if start >= end:
        sys.exit(f"Start date {start} is not before end date {end}.")

    return start.isoformat(), end.isoformat()


def to_iso(value) -> str:
    """Yahoo returns tz-aware intraday stamps and tz-naive daily ones."""
    stamp = value.to_pydatetime()
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    return stamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def fetch(symbol: str, interval: str, start: str, end: str) -> list[dict]:
    frame = yf.download(
        tickers=SYMBOLS[symbol],
        start=start,
        end=end,
        interval=interval,
        auto_adjust=False,
        progress=False,
        # One ticker at a time keeps the frame flat and the failure modes obvious.
        group_by="column",
    )

    if frame is None or frame.empty:
        return []

    # yfinance returns MultiIndex columns in some versions even for one ticker.
    if hasattr(frame.columns, "nlevels") and frame.columns.nlevels > 1:
        frame.columns = frame.columns.get_level_values(0)

    frame = frame.dropna(subset=["Open", "High", "Low", "Close"])

    bars = []
    for stamp, row in frame.iterrows():
        raw_volume = row["Volume"]
        # NaN is the one value that is not equal to itself.
        volume = int(raw_volume) if raw_volume == raw_volume else 0
        # Bars with no trading contribute nothing but noise to a volume baseline.
        if volume <= 0:
            continue
        bars.append(
            {
                "timestamp": to_iso(stamp),
                "open": round(float(row["Open"]), 4),
                "high": round(float(row["High"]), 4),
                "low": round(float(row["Low"]), 4),
                "close": round(float(row["Close"]), 4),
                "volume": volume,
            }
        )

    return bars


def main() -> int:
    load_env()

    parser = argparse.ArgumentParser(description="Fetch Yahoo Finance futures bars")
    parser.add_argument("symbols", nargs="*", default=[], help="ES NQ CL GC")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fetch a few days per symbol to confirm they resolve, then exit",
    )
    args = parser.parse_args()

    interval = os.environ.get("MARKET_DATA_INTERVAL", "1h")
    selected = [s.upper() for s in args.symbols] or list(SYMBOLS)
    unknown = [s for s in selected if s not in SYMBOLS]
    if unknown:
        sys.exit(f"Unknown symbol(s): {', '.join(unknown)}")

    if args.check:
        end = date.today()
        start = end - timedelta(days=7)
        for symbol in selected:
            bars = fetch(symbol, "1d", start.isoformat(), end.isoformat())
            if bars:
                print(
                    f"{symbol} ({SYMBOLS[symbol]}): OK, "
                    f"{len(bars)} daily bars, latest close {bars[-1]['close']}"
                )
            else:
                print(f"{symbol} ({SYMBOLS[symbol]}): no data returned")
        return 0

    start, end = resolve_window(interval)
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    wrote = 0

    for symbol in selected:
        print(f"Fetching {symbol} ({SYMBOLS[symbol]}, {interval})...")
        bars = fetch(symbol, interval, start, end)

        if not bars:
            print(f"  no observations returned for {symbol}; skipping")
            continue

        payload = {
            "symbol": symbol,
            "sourceSymbol": SYMBOLS[symbol],
            "dataset": "Yahoo Finance continuous futures",
            "schema": interval,
            "start": start,
            "end": end,
            "source": "Yahoo Finance",
            "retrievedAt": datetime.now(timezone.utc).isoformat(),
            "bars": bars,
        }

        out_path = RAW_DIR / f"{symbol}.bars.json"
        out_path.write_text(json.dumps(payload, separators=(",", ":")))
        print(f"  downloaded {len(bars):,} observations")
        print(f"  saved {out_path.relative_to(ROOT)}")
        wrote += 1

    if wrote == 0:
        print("\nNothing was written. Try: python scripts/fetch_market_data.py --check")
        return 1

    print("\nNext: npm run data:build")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
