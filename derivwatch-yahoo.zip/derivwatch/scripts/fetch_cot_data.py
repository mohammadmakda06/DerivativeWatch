"""Fetch CFTC Commitments of Traders positioning into data/raw/cot.json.

Source: the CFTC's own Public Reporting Environment (Socrata), which serves the
weekly COT reports as JSON. No key is required; COT_APP_TOKEN raises the
anonymous rate limit if you have one.

    python scripts/fetch_cot_data.py
    python scripts/fetch_cot_data.py --inspect GOLD   # find a contract code

Two reports are used, because the trader categories differ by market:
  * Traders in Financial Futures  - ES, NQ (dealer, asset manager, leveraged)
  * Disaggregated                 - CL, GC (producer/merchant, swap, managed money)

Both are futures-only. DerivWatch keeps each market's real category names
rather than flattening them into one label they do not share.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"

CONTRACTS = {
    "ES": {"report": "tff", "code": "13874A"},
    "NQ": {"report": "tff", "code": "209742"},
    "CL": {"report": "disaggregated", "code": "067651"},
    "GC": {"report": "disaggregated", "code": "088691"},
}

# Socrata column names differ between the two reports.
FIELD_MAP = {
    "tff": {
        "speculative_long": "lev_money_positions_long",
        "speculative_short": "lev_money_positions_short",
        "hedger_long": "dealer_positions_long_all",
        "hedger_short": "dealer_positions_short_all",
    },
    "disaggregated": {
        "speculative_long": "m_money_positions_long_all",
        "speculative_short": "m_money_positions_short_all",
        "hedger_long": "prod_merc_positions_long",
        "hedger_short": "prod_merc_positions_short",
    },
}

COMMON_FIELDS = {
    "report_date": "report_date_as_yyyy_mm_dd",
    "market_name": "market_and_exchange_names",
    "open_interest": "open_interest_all",
}


def load_env() -> None:
    for name in (".env.local", ".env"):
        path = ROOT / name
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())


def request_json(url: str, token: str | None) -> list[dict]:
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    if token:
        request.add_header("X-App-Token", token)
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.loads(response.read().decode("utf-8"))


def to_number(value) -> float | None:
    """Socrata returns numerics as strings; blanks and junk become None."""
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def build_url(base: str, dataset: str, params: dict[str, str]) -> str:
    query = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
    return f"{base.rstrip('/')}/{dataset}.json?{query}"


def inspect(base: str, datasets: dict[str, str], token: str | None, term: str) -> int:
    """Print contract codes whose market name matches `term`, to verify config."""
    for report, dataset in datasets.items():
        params = {
            "$select": "cftc_contract_market_code,market_and_exchange_names",
            "$where": f"upper(market_and_exchange_names) like upper('%{term}%')",
            "$group": "cftc_contract_market_code,market_and_exchange_names",
            "$limit": "25",
        }
        rows = request_json(build_url(base, dataset, params), token)
        print(f"\n{report} ({dataset}):")
        for row in rows:
            print(f"  {row['cftc_contract_market_code']}  {row['market_and_exchange_names']}")
    return 0


def main() -> int:
    load_env()

    parser = argparse.ArgumentParser(description="Fetch CFTC COT positioning")
    parser.add_argument("--inspect", metavar="TERM", help="List matching contract codes")
    args = parser.parse_args()

    base = os.environ.get("COT_API_BASE_URL", "https://publicreporting.cftc.gov/resource")
    datasets = {
        "tff": os.environ.get("COT_TFF_DATASET", "gpe5-46if"),
        "disaggregated": os.environ.get("COT_DISAGGREGATED_DATASET", "72hg-3qgp"),
    }
    weeks = int(os.environ.get("COT_WEEKS", "52"))
    token = os.environ.get("COT_APP_TOKEN") or None

    if args.inspect:
        return inspect(base, datasets, token, args.inspect)

    series: dict[str, dict] = {}

    for symbol, config in CONTRACTS.items():
        report = config["report"]
        dataset = datasets[report]
        fields = FIELD_MAP[report]

        select = ",".join(
            [
                COMMON_FIELDS["report_date"],
                COMMON_FIELDS["market_name"],
                COMMON_FIELDS["open_interest"],
                *fields.values(),
            ]
        )
        params = {
            "$select": select,
            "$where": f"cftc_contract_market_code='{config['code']}'",
            "$order": f"{COMMON_FIELDS['report_date']} DESC",
            "$limit": str(weeks),
        }

        print(f"Fetching {symbol} COT ({report}, code {config['code']})...")
        rows = request_json(build_url(base, dataset, params), token)

        observations = []
        skipped = 0
        for row in rows:
            report_date = row.get(COMMON_FIELDS["report_date"])
            spec_long = to_number(row.get(fields["speculative_long"]))
            spec_short = to_number(row.get(fields["speculative_short"]))
            hedge_long = to_number(row.get(fields["hedger_long"]))
            hedge_short = to_number(row.get(fields["hedger_short"]))
            open_interest = to_number(row.get(COMMON_FIELDS["open_interest"]))

            if not report_date or None in (spec_long, spec_short, hedge_long, hedge_short):
                skipped += 1
                continue

            observations.append(
                {
                    "reportDate": report_date[:10],
                    "openInterest": int(open_interest or 0),
                    "speculativeLong": int(spec_long),
                    "speculativeShort": int(spec_short),
                    "hedgerLong": int(hedge_long),
                    "hedgerShort": int(hedge_short),
                }
            )

        if not observations:
            print(f"  no usable rows for {symbol}; check the contract code")
            continue

        observations.sort(key=lambda o: o["reportDate"])
        series[symbol] = {
            "symbol": symbol,
            "report": report,
            "contractCode": config["code"],
            "marketName": rows[0].get(COMMON_FIELDS["market_name"], "").strip(),
            "observations": observations,
        }
        note = f" ({skipped} incomplete rows skipped)" if skipped else ""
        print(f"  {len(observations)} weekly reports, latest {observations[-1]['reportDate']}{note}")

    if not series:
        sys.exit("No COT data retrieved. Try: python scripts/fetch_cot_data.py --inspect GOLD")

    payload = {
        "source": "CFTC Commitments of Traders",
        "endpoint": base,
        "datasets": datasets,
        "series": series,
    }
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RAW_DIR / "cot.json"
    out_path.write_text(json.dumps(payload, separators=(",", ":")))
    print(f"\nSaved {out_path.relative_to(ROOT)}")
    print("Next: npm run data:build")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
