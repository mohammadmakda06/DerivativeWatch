/**
 * Generate clearly-labelled synthetic fixtures so the UI can be developed
 * without fetching anything.
 *
 *   npm run data:fixtures && npm run data:build
 *
 * These are NOT market prices. Every series starts from an arbitrary level of
 * 1,000 and is driven by a seeded random walk, so no number here can be
 * mistaken for a quote. Each file carries `isFixture: true`, which the site
 * surfaces as a banner on every page that displays the data.
 */
import { promises as fs } from "node:fs";
import path from "node:path";

import { contractList } from "../lib/contracts";

const RAW_DIR = path.join(process.cwd(), "data", "raw");

/** Mulberry32 - small, seeded, reproducible. */
function makeRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Box-Muller, for normally distributed shocks. */
function gaussian(random: () => number): number {
  const u = Math.max(random(), Number.EPSILON);
  const v = random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const BARS = 1200;
const HOUR = 3_600_000;

function generate(symbol: string, seed: number) {
  const random = makeRandom(seed);
  const bars = [];
  let close = 1000;
  const end = Date.UTC(2026, 8, 19, 0, 0, 0);
  const start = end - BARS * HOUR;

  // A handful of deliberate shocks so the signal logic has something to find.
  const shockIndices = new Set([180, 431, 694, 705, 1012]);

  for (let index = 0; index < BARS; index += 1) {
    const shocked = shockIndices.has(index);
    const drift = gaussian(random) * 0.0018 + (shocked ? gaussian(random) * 0.012 : 0);
    const open = close;
    close = Math.max(1, open * (1 + drift));
    const spread = Math.abs(drift) + 0.0006 + random() * 0.0008;
    const high = Math.max(open, close) * (1 + spread / 2);
    const low = Math.min(open, close) * (1 - spread / 2);

    const baseVolume = 9000 + Math.sin(index / 7) * 2200;
    const volume = Math.round(
      Math.max(
        250,
        baseVolume * (0.75 + random() * 0.5) * (shocked ? 4 + random() * 3 : 1),
      ),
    );

    bars.push({
      timestamp: new Date(start + index * HOUR).toISOString(),
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume,
    });
  }

  return {
    symbol,
    sourceSymbol: `${symbol}=F`,
    dataset: "FIXTURE",
    schema: "ohlcv-1h",
    start: new Date(start).toISOString().slice(0, 10),
    end: new Date(end).toISOString().slice(0, 10),
    source: "Synthetic fixture (not market data)",
    isFixture: true,
    bars,
  };
}

function generateCot() {
  const series: Record<string, unknown> = {};

  contractList.forEach((contract, contractIndex) => {
    const random = makeRandom(7000 + contractIndex * 13);
    const observations = [];
    let speculativeLong = 180_000;
    let speculativeShort = 150_000;
    let hedgerLong = 220_000;
    let hedgerShort = 260_000;
    const firstTuesday = Date.UTC(2025, 8, 23);

    for (let week = 0; week < 52; week += 1) {
      speculativeLong += Math.round(gaussian(random) * 6000);
      speculativeShort += Math.round(gaussian(random) * 6000);
      hedgerLong += Math.round(gaussian(random) * 7000);
      hedgerShort += Math.round(gaussian(random) * 7000);

      observations.push({
        reportDate: new Date(firstTuesday + week * 7 * 86_400_000)
          .toISOString()
          .slice(0, 10),
        openInterest:
          speculativeLong + speculativeShort + hedgerLong + hedgerShort,
        speculativeLong: Math.max(0, speculativeLong),
        speculativeShort: Math.max(0, speculativeShort),
        hedgerLong: Math.max(0, hedgerLong),
        hedgerShort: Math.max(0, hedgerShort),
      });
    }

    series[contract.symbol] = {
      symbol: contract.symbol,
      report: contract.cot.report,
      contractCode: contract.cot.contractCode,
      marketName: `${contract.name} (synthetic fixture)`,
      observations,
    };
  });

  return {
    source: "Synthetic fixture (not CFTC data)",
    endpoint: "fixture",
    intermediary: null,
    isFixture: true,
    series,
  };
}

async function main() {
  await fs.mkdir(RAW_DIR, { recursive: true });

  for (const [index, contract] of contractList.entries()) {
    const payload = generate(contract.symbol, 1000 + index * 37);
    await fs.writeFile(
      path.join(RAW_DIR, `${contract.symbol}.bars.json`),
      JSON.stringify(payload),
    );
    console.log(`Wrote fixture data/raw/${contract.symbol}.bars.json (${BARS} bars)`);
  }

  await fs.writeFile(
    path.join(RAW_DIR, "cot.json"),
    JSON.stringify(generateCot()),
  );
  console.log("Wrote fixture data/raw/cot.json (52 weekly reports per market)");
  console.log("\nThese are synthetic values, not market data. Next: npm run data:build");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
