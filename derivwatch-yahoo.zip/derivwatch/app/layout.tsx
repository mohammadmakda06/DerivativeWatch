import type { Metadata } from "next";
import { IBM_Plex_Mono, IBM_Plex_Sans } from "next/font/google";

import Footer from "@/components/Footer";
import Header from "@/components/Header";

import "./globals.css";

const sans = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-sans",
  display: "swap",
});

const mono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://derivwatch.vercel.app"),
  title: {
    default: "DerivWatch — Futures Market Intelligence",
    template: "%s — DerivWatch",
  },
  description:
    "Explore unusual activity in real futures markets using historical market data and CFTC positioning.",
  openGraph: {
    title: "DerivWatch — Futures Market Intelligence",
    description:
      "Explore unusual activity in real futures markets using historical market data and CFTC positioning.",
    type: "website",
    siteName: "DerivWatch",
  },
  twitter: {
    card: "summary_large_image",
    title: "DerivWatch — Futures Market Intelligence",
    description:
      "Statistically unusual price and volume activity in four futures markets, with CFTC positioning as context.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable}`}>
      <body className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
