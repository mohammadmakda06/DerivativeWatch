import Link from "next/link";

import DataFreshness from "@/components/DataFreshness";
import DataSourceCard from "@/components/DataSourceCard";
import FixtureBanner from "@/components/FixtureBanner";
import MarketGrid from "@/components/MarketGrid";
import SignalCard from "@/components/SignalCard";
import { daysSince, getAllMarketDatasets, getFeaturedSignal } from "@/lib/data";

export default async function HomePage() {
  const datasets = await getAllMarketDatasets();
  const featured = await getFeaturedSignal();

  const loaded = datasets.filter((entry) => entry.dataset !== null);
  const usingFixtures = loaded.some((entry) => entry.dataset?.meta.isFixture);
  const latestTimestamp = loaded
    .map((entry) => entry.dataset?.stats.latestTimestamp ?? null)
    .filter((value): value is string => value !== null)
    .sort()
    .at(-1) ?? null;

  return (
    <>
      {/* Hero ------------------------------------------------------- */}
      <section className="shell border-b border-rule py-16 sm:py-24">
        <div className="max-w-3xl">
          <h1 className="font-mono text-4xl font-medium tracking-tight text-text sm:text-6xl">
            DerivWatch
          </h1>
          <p className="mt-3 text-xl text-text sm:text-2xl">
            Finding unusual activity in futures markets.
          </p>
          <p className="mt-5 max-w-[60ch] text-base leading-relaxed text-muted">
            Explore real futures market data and CFTC positioning through
            transparent, explainable statistical signals.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/markets" className="btn-primary">
              Explore markets
            </Link>
            <Link href="/methodology" className="btn-secondary">
              How it works
            </Link>
          </div>

          <p className="mt-8 font-mono text-micro leading-relaxed text-faint">
            market data → rolling baseline → unusual activity → positioning
            context
          </p>
        </div>
      </section>

      {/* Market snapshot -------------------------------------------- */}
      <section aria-labelledby="snapshot" className="shell py-12">
        <div className="mb-5 flex flex-wrap items-baseline justify-between gap-3">
          <h2 id="snapshot" className="text-lg text-text">
            Market snapshot
          </h2>
          <DataFreshness
            timestamp={latestTimestamp}
            days={daysSince(latestTimestamp)}
          />
        </div>

        {usingFixtures ? (
          <div className="mb-5">
            <FixtureBanner />
          </div>
        ) : null}

        <MarketGrid datasets={datasets} />
      </section>

      {/* Featured signal -------------------------------------------- */}
      {featured ? (
        <section aria-labelledby="featured" className="shell py-12">
          <div className="mb-5 flex flex-wrap items-baseline justify-between gap-3">
            <h2 id="featured" className="text-lg text-text">
              Featured market signal
            </h2>
            <p className="font-mono text-sm text-muted">
              {featured.symbol} — {featured.name}
            </p>
          </div>

          <SignalCard signal={featured.signal} />

          <Link
            href={`/markets/${featured.symbol}`}
            className="btn-secondary mt-4"
          >
            View market
          </Link>
        </section>
      ) : null}

      {/* How it works ------------------------------------------------ */}
      <section aria-labelledby="pipeline" className="shell py-12">
        <h2 id="pipeline" className="mb-5 text-lg text-text">
          How it works
        </h2>

        <ol className="grid grid-cols-1 gap-px bg-rule md:grid-cols-3">
          {[
            {
              step: "01",
              title: "Real data",
              body: "Historical futures observations from Yahoo Finance, weekly positioning from the CFTC.",
            },
            {
              step: "02",
              title: "Statistical baselines",
              body: "Each observation is compared with the 20 observations that preceded it.",
            },
            {
              step: "03",
              title: "Market signals",
              body: "Price or volume more than three standard deviations from that baseline is flagged.",
            },
          ].map((item) => (
            <li key={item.step} className="bg-ink p-6">
              <p className="font-mono text-sm text-accent">{item.step}</p>
              <p className="mt-3 text-text">{item.title}</p>
              <p className="mt-2 max-w-[42ch] text-sm leading-relaxed text-muted">
                {item.body}
              </p>
            </li>
          ))}
        </ol>
      </section>

      {/* Data sources ------------------------------------------------ */}
      <section aria-labelledby="sources" className="shell py-12">
        <h2 id="sources" className="mb-5 text-lg text-text">
          Data sources
        </h2>

        <div className="grid gap-4 md:grid-cols-3">
          <DataSourceCard
            role="Market data"
            name="Yahoo Finance"
            description="Historical continuous front-month futures series for ES, NQ, CL and GC, retrieved server-side and processed into a compact dataset."
            href="https://finance.yahoo.com/quote/ES%3DF/"
            linkLabel="ES=F on Yahoo Finance"
          />
          <DataSourceCard
            role="Positioning"
            name="CFTC Commitments of Traders"
            description="Weekly futures positioning data published by the Commodity Futures Trading Commission."
            href="https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm"
            linkLabel="CFTC COT reports"
          />
          <DataSourceCard
            role="Analytics"
            name="DerivWatch"
            description="Rolling statistical baselines, z-scores and anomaly calculations, documented in full on the methodology page."
          />
        </div>
      </section>
    </>
  );
}
