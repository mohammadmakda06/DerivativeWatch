import type { Metadata } from "next";

import MethodologySection from "@/components/MethodologySection";
import { contractList } from "@/lib/contracts";

export const metadata: Metadata = {
  title: "Methodology",
  description:
    "How DerivWatch builds rolling statistical baselines, calculates z-scores and flags unusual futures market activity.",
};

function Formula({ children }: { children: React.ReactNode }) {
  return (
    <pre className="overflow-x-auto border border-rule bg-panel px-4 py-3 font-mono text-xs leading-relaxed text-text">
      {children}
    </pre>
  );
}

export default function MethodologyPage() {
  return (
    <div className="shell py-12">
      <header className="mb-10 max-w-2xl">
        <h1 className="text-2xl text-text">Methodology</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Every signal on this site comes from arithmetic you can reproduce by
          hand. There is no model to trust and no weights to tune — just rolling
          means, standard deviations and two thresholds.
        </p>
      </header>

      <div className="space-y-10">
        <MethodologySection id="data" title="Market data">
          <p>
            Historical futures observations come from Yahoo Finance&rsquo;s
            continuous front-month series for each contract root. DerivWatch
            covers four contracts:{" "}
            {contractList.map((contract, index) => (
              <span key={contract.symbol}>
                {index > 0 ? ", " : ""}
                <span className="font-mono text-text">{contract.symbol}</span> (
                {contract.name})
              </span>
            ))}
            .
          </p>
          <p>
            Each contract is requested as its continuous series —{" "}
            <span className="font-mono text-text">ES=F</span> and its
            equivalents — which rolls with the front contract. That matters for
            volume-based signals: a fixed-expiry series stays on a contract
            after liquidity has rolled away from it, which would put an
            artificial volume cliff in the middle of the baseline.
          </p>
          <p>
            Data is fetched server-side by a script that runs outside the
            website, and the processed output is committed as JSON. Nothing is
            fetched in the browser and the deployed site holds no credentials.
            Observations are historical, not live.
          </p>
          <p className="border-l-2 border-rule pl-4">
            One caveat worth stating rather than hiding: Yahoo has no official
            public data API, so this uses the endpoints its own site calls, via
            the yfinance library. Volume on the continuous series reflects the
            front contract and occasionally arrives incomplete for a session.
            Bars reporting zero volume are dropped during ingestion, because a
            zero would distort the rolling baseline that everything else
            depends on. A paid vendor feed would be the right choice for
            anything beyond a research project.
          </p>
        </MethodologySection>

        <MethodologySection id="cot" title="CFTC positioning">
          <p>
            The Commitments of Traders report is published weekly by the
            Commodity Futures Trading Commission and breaks each market&rsquo;s
            open interest down by category of participant, as of the preceding
            Tuesday.
          </p>
          <p>
            The two reports used here describe different markets with different
            categories, so DerivWatch keeps the real category names rather than
            flattening them into one label. ES and NQ come from the Traders in
            Financial Futures report, where the comparison is between leveraged
            funds and dealers. CL and GC come from the Disaggregated report,
            where it is between managed money and producers or merchants. Both
            are futures-only.
          </p>
          <Formula>{`managed_money_net  = managed_money_long  - managed_money_short
commercial_net     = commercial_long     - commercial_short`}</Formula>
          <p>
            Positioning appears on this site as context for the market, not as
            an input to any signal and not as a forecast of price direction.
          </p>
        </MethodologySection>

        <MethodologySection id="baseline" title="Rolling baseline">
          <p>
            Each observation is compared with the 20 observations immediately
            before it. Twenty is long enough for the mean and standard deviation
            to be meaningful and short enough to track a changing market, so
            &ldquo;unusual&rdquo; means unusual for right now rather than unusual
            for the whole sample.
          </p>
          <p>
            The current observation is deliberately excluded from its own
            baseline. If it were included, a large print would inflate the mean
            it is being measured against and partly hide itself.
          </p>
          <p>
            The first 20 observations of any series therefore have no baseline
            and carry no score. They are shown on the charts but can never be
            flagged.
          </p>
        </MethodologySection>

        <MethodologySection id="zscore" title="Z-score">
          <p>
            A z-score expresses a value as a number of standard deviations from
            the mean of its baseline.
          </p>
          <Formula>{`z = (x - mean) / standard_deviation`}</Formula>
          <p>
            Volume is used directly. Price uses simple returns rather than price
            levels, because the level of a futures contract trends while its
            returns are roughly stationary — a z-score of a price level would
            mostly measure the trend.
          </p>
          <Formula>{`return       = close / previous_close - 1
price_z      = (return - rolling_mean) / rolling_std
volume_z     = (volume - rolling_mean) / rolling_std`}</Formula>
          <p>
            Standard deviation uses the sample formula (n − 1). Where a baseline
            is flat, its standard deviation is zero and no z-score exists; those
            observations are left unscored rather than being assigned an
            infinite or zero value.
          </p>
        </MethodologySection>

        <MethodologySection id="rules" title="Signal rules">
          <p>Three signals, all of them thresholds on the z-scores above.</p>
          <Formula>{`Unusual volume        volume_z >= 3
Unusual price         abs(price_z) >= 3
Price + volume        both conditions, same observation`}</Formula>
          <p>
            Price is two-sided because a large fall is as notable as a large
            rise. Volume is one-sided: unusually quiet trading is not what this
            is looking for.
          </p>
          <p>
            Three standard deviations is a convention, not a law. Under a normal
            distribution roughly one observation in 370 lies beyond it, but
            financial returns have heavier tails than that, so flags are more
            common than the normal approximation suggests. The threshold is
            configurable.
          </p>
        </MethodologySection>

        <MethodologySection id="score" title="Surveillance Signal Score">
          <p>
            Each flagged observation gets a score from 0 to 100. Price and
            volume contribute up to 50 points each, saturating at five standard
            deviations.
          </p>
          <Formula>{`price_component  = min(abs(price_z)  / 5, 1) * 50
volume_component = min(abs(volume_z) / 5, 1) * 50

score = price_component + volume_component`}</Formula>
          <p>
            A higher score indicates that the observed market activity is more
            unusual relative to the historical baseline used by DerivWatch. That
            is the entire claim. The score is not a probability of misconduct,
            not a likelihood of manipulation, and not a ranking of participants.
          </p>
          <p>
            Saturation is intentional. Beyond about five standard deviations the
            distinction between one extreme observation and another stops
            carrying useful information, and a score that kept climbing would
            imply a precision the method does not have.
          </p>
        </MethodologySection>

        <MethodologySection id="limitations" title="Limitations">
          <p className="text-text">
            DerivWatch identifies statistically unusual market activity. It does
            not determine whether manipulation, misconduct, or another
            regulatory violation occurred.
          </p>
          <ul className="list-disc space-y-2 pl-5">
            <li>
              Public market data shows what happened, not who did it or why.
              Order attribution, intent and participant identity are all absent.
            </li>
            <li>
              CFTC positioning is aggregated by category and published weekly
              with a lag, so it cannot be matched to any individual observation.
            </li>
            <li>
              Statistical anomalies routinely have legitimate explanations:
              scheduled economic releases, contract rolls, index rebalancing,
              settlement windows, holiday sessions and thin overnight liquidity
              all produce z-scores like these.
            </li>
            <li>
              A signal is a starting point for human review, not a conclusion.
              Context determines whether anything here is interesting at all.
            </li>
            <li>
              The score measures distance from a baseline. It is not a
              probability of wrongdoing.
            </li>
          </ul>
        </MethodologySection>
      </div>
    </div>
  );
}
