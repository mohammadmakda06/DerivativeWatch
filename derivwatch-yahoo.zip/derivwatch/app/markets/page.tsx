import type { Metadata } from "next";

import DataFreshness from "@/components/DataFreshness";
import EmptyState from "@/components/EmptyState";
import FixtureBanner from "@/components/FixtureBanner";
import MarketGrid from "@/components/MarketGrid";
import { daysSince, getAllMarketDatasets } from "@/lib/data";

export const metadata: Metadata = {
  title: "Markets",
  description:
    "Four futures contracts with historical price, volume and statistically unusual activity.",
};

export default async function MarketsPage() {
  const datasets = await getAllMarketDatasets();
  const loaded = datasets.filter((entry) => entry.dataset !== null);
  const usingFixtures = loaded.some((entry) => entry.dataset?.meta.isFixture);

  const latestTimestamp = loaded
    .map((entry) => entry.dataset?.stats.latestTimestamp ?? null)
    .filter((value): value is string => value !== null)
    .sort()
    .at(-1) ?? null;

  return (
    <div className="shell py-12">
      <header className="mb-8 max-w-2xl">
        <h1 className="text-2xl text-text">Market explorer</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Four liquid futures contracts, each with historical observations,
          rolling statistical baselines and the observations that fell outside
          them. Select a contract to see the detail.
        </p>
        <div className="mt-4">
          <DataFreshness
            timestamp={latestTimestamp}
            days={daysSince(latestTimestamp)}
          />
        </div>
      </header>

      {usingFixtures ? (
        <div className="mb-6">
          <FixtureBanner />
        </div>
      ) : null}

      {loaded.length === 0 ? (
        <EmptyState
          title="No market observations available."
          body="Nothing has been ingested yet. Fetch the data, then rebuild the processed datasets."
          action="python scripts/fetch_market_data.py && npm run data:build"
        />
      ) : (
        <MarketGrid datasets={datasets} />
      )}
    </div>
  );
}
