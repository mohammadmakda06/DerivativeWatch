import type { Metadata } from "next";
import { notFound } from "next/navigation";

import CotPositioning from "@/components/CotPositioning";
import DataFreshness from "@/components/DataFreshness";
import EmptyState from "@/components/EmptyState";
import FixtureBanner from "@/components/FixtureBanner";
import MarketCharts from "@/components/MarketCharts";
import SignalTable from "@/components/SignalTable";
import Stat from "@/components/Stat";
import { contractSymbols, getContract } from "@/lib/contracts";
import {
  daysSince,
  getCotDataset,
  getMarketDataset,
} from "@/lib/data";
import {
  formatPercent,
  formatPrice,
  formatTimestamp,
  formatVolatility,
  formatVolume,
  signalLabels,
} from "@/lib/format";

type Params = { params: { symbol: string } };

export function generateStaticParams() {
  return contractSymbols.map((symbol) => ({ symbol }));
}

export function generateMetadata({ params }: Params): Metadata {
  const contract = getContract(params.symbol);
  if (!contract) return { title: "Market not found" };
  return {
    title: `${contract.symbol} — ${contract.name}`,
    description: `Historical price, volume and statistically unusual activity for ${contract.name} (${contract.symbol}) futures, with CFTC positioning context.`,
  };
}

export default async function MarketDetailPage({ params }: Params) {
  const contract = getContract(params.symbol);
  if (!contract) notFound();

  const dataset = await getMarketDataset(contract.symbol);
  const cot = await getCotDataset();
  const series = cot?.series?.[contract.symbol] ?? null;

  return (
    <div className="shell py-12">
      <header className="border-b border-rule pb-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-mono text-3xl text-text">{contract.symbol}</h1>
            <p className="mt-1 text-lg text-muted">{contract.name}</p>
          </div>
          <p className="text-micro text-faint">
            {contract.assetClass} · {contract.exchange}
            {dataset ? ` · ${dataset.contract.sourceSymbol}` : ""}
          </p>
        </div>
      </header>

      {dataset?.meta.isFixture ? (
        <div className="mt-6">
          <FixtureBanner />
        </div>
      ) : null}

      {!dataset ? (
        <div className="mt-8">
          <EmptyState
            title="Market data unavailable."
            body="Run the data ingestion script to update this dataset."
            action={`python scripts/fetch_market_data.py ${contract.symbol} && npm run data:build`}
          />
        </div>
      ) : (
        <>
          <section aria-label="Latest observation" className="py-8">
            <dl className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-5">
              <Stat
                label="Latest price"
                value={formatPrice(dataset.stats.latestClose, contract.priceDecimals)}
              />
              <Stat
                label="Recent change"
                value={formatPercent(dataset.stats.latestChange)}
                tone={
                  dataset.stats.latestChange === null
                    ? "neutral"
                    : dataset.stats.latestChange >= 0
                      ? "up"
                      : "down"
                }
              />
              <Stat label="Volume" value={formatVolume(dataset.stats.latestVolume)} />
              <Stat
                label="Volatility"
                value={formatVolatility(dataset.stats.latestVolatility)}
                hint={`rolling ${dataset.meta.window}-period σ of returns`}
              />
              <Stat
                label="Signal score"
                value={
                  dataset.summary.latestSignal
                    ? `${dataset.summary.latestSignal.score} / 100`
                    : "—"
                }
                tone={dataset.summary.latestSignal ? "signal" : "neutral"}
                hint={
                  dataset.summary.latestSignal
                    ? `latest signal ${formatTimestamp(dataset.summary.latestSignal.timestamp)}`
                    : "no signals in this dataset"
                }
              />
            </dl>
            <div className="mt-6">
              <DataFreshness
                timestamp={dataset.stats.latestTimestamp}
                days={daysSince(dataset.stats.latestTimestamp)}
              />
            </div>
          </section>

          <MarketCharts
            bars={dataset.bars.map((bar) => ({
              timestamp: bar.timestamp,
              close: bar.close,
              volume: bar.volume,
              priceZScore: bar.priceZScore,
              volumeZScore: bar.volumeZScore,
              signalType: bar.signalType,
            }))}
            signals={dataset.signals}
            priceDecimals={contract.priceDecimals}
            volumeThreshold={dataset.meta.volumeThreshold}
          />

          <section aria-labelledby="summary-heading" className="mt-14 space-y-5">
            <h2 id="summary-heading" className="text-lg text-text">
              Surveillance summary
            </h2>

            <dl className="grid grid-cols-2 gap-6 sm:grid-cols-4">
              <Stat
                label="Signals detected"
                value={String(dataset.summary.signalCount)}
              />
              <Stat
                label="High-score signals"
                value={String(dataset.summary.highScoreCount)}
                hint="score of 70 or above"
              />
              <Stat
                label="Average signal score"
                value={
                  dataset.summary.averageScore === null
                    ? "—"
                    : String(dataset.summary.averageScore)
                }
              />
              <Stat
                label="Most recent signal"
                value={
                  dataset.summary.latestSignal
                    ? signalLabels[dataset.summary.latestSignal.type]
                    : "—"
                }
              />
            </dl>

            <div className="panel p-5">
              <SignalTable signals={dataset.signals} />
            </div>

            <p className="max-w-[68ch] text-sm leading-relaxed text-muted">
              Signals describe how far an observation sits from the{" "}
              {dataset.meta.window}-period baseline that preceded it. They are
              statistical flags, not determinations about any participant&rsquo;s
              conduct.
            </p>
          </section>

          <div className="mt-14">
            <CotPositioning
              series={series}
              intermediary={cot?.meta.intermediary ?? null}
            />
          </div>
        </>
      )}
    </div>
  );
}
