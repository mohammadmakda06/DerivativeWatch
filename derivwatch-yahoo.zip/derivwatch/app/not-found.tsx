import Link from "next/link";

export default function NotFound() {
  return (
    <div className="shell py-24">
      <h1 className="text-2xl text-text">Page not found</h1>
      <p className="mt-3 max-w-[56ch] text-sm leading-relaxed text-muted">
        That page doesn&rsquo;t exist. DerivWatch covers four futures contracts:
        ES, NQ, CL and GC.
      </p>
      <Link href="/markets" className="btn-secondary mt-6">
        Explore markets
      </Link>
    </div>
  );
}
