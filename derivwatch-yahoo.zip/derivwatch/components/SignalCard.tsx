import {
  formatPrice,
  formatTimestamp,
  formatVolume,
  formatZScore,
  signalLabels,
} from "@/lib/format";
import type { SurveillanceSignal } from "@/lib/types";

export default function SignalCard({
  signal,
  dense = false,
}: {
  signal: SurveillanceSignal;
  dense?: boolean;
}) {
  return (
    <article className={`panel ${dense ? "p-4" : "p-5"}`}>
      <header className="flex flex-wrap items-baseline justify-between gap-3">
        <h3 className="text-signal">{signalLabels[signal.type]}</h3>
        <p className="text-micro text-faint">
          {formatTimestamp(signal.timestamp)} UTC
        </p>
      </header>

      <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
        <div>
          <dt className="rule-label">Signal score</dt>
          <dd className="font-mono text-lg tabular text-signal">
            {signal.score} <span className="text-faint">/ 100</span>
          </dd>
        </div>
        <div>
          <dt className="rule-label">Price z-score</dt>
          <dd className="font-mono text-lg tabular text-text">
            {formatZScore(signal.priceZScore)}
          </dd>
        </div>
        <div>
          <dt className="rule-label">Volume z-score</dt>
          <dd className="font-mono text-lg tabular text-text">
            {formatZScore(signal.volumeZScore)}
          </dd>
        </div>
        <div>
          <dt className="rule-label">Close / volume</dt>
          <dd className="font-mono text-lg tabular text-text">
            {formatPrice(signal.close)}{" "}
            <span className="text-faint">· {formatVolume(signal.volume)}</span>
          </dd>
        </div>
      </dl>

      <p className="mt-4 border-t border-rule pt-4 text-sm leading-relaxed text-muted">
        {signal.description}
      </p>
    </article>
  );
}
