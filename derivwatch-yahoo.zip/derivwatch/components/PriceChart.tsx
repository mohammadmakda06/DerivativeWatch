"use client";

import {
  Area,
  CartesianGrid,
  ComposedChart,
  ResponsiveContainer,
  Scatter,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { formatAxisTime, formatPrice, formatTimestamp, signalLabels } from "@/lib/format";
import type { ChartBar, SurveillanceSignal } from "@/lib/types";

type Props = {
  bars: ChartBar[];
  signals: SurveillanceSignal[];
  priceDecimals: number;
  onSelectSignal: (signal: SurveillanceSignal) => void;
  selectedTimestamp?: string | null;
};

type MarkerDatum = {
  timestamp: string;
  close: number;
  signal: SurveillanceSignal;
};

function PriceTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const point = payload[0].payload as ChartBar;
  return (
    <div className="border border-rule bg-panel px-3 py-2 text-xs">
      <p className="font-mono tabular text-text">{formatPrice(point.close)}</p>
      <p className="mt-1 text-faint">{formatTimestamp(point.timestamp)} UTC</p>
    </div>
  );
}

/** Amber ring on the price line wherever a signal was flagged. */
function SignalMarker(props: any) {
  const { cx, cy, payload, onSelectSignal, selectedTimestamp } = props;
  if (cx === undefined || cy === undefined) return null;
  const datum = payload as MarkerDatum;
  const selected = selectedTimestamp === datum.timestamp;

  return (
    <g
      role="button"
      tabIndex={0}
      aria-label={`${signalLabels[datum.signal.type]} on ${formatTimestamp(datum.timestamp)}, score ${datum.signal.score} out of 100`}
      className="cursor-pointer focus:outline-none"
      onClick={() => onSelectSignal(datum.signal)}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onSelectSignal(datum.signal);
        }
      }}
    >
      <circle cx={cx} cy={cy} r={selected ? 9 : 7} fill="#D9A441" fillOpacity={0.16} />
      <circle
        cx={cx}
        cy={cy}
        r={selected ? 4.5 : 3.5}
        fill="#D9A441"
        stroke="#0A0D12"
        strokeWidth={1.5}
      />
    </g>
  );
}

export default function PriceChart({
  bars,
  signals,
  priceDecimals,
  onSelectSignal,
  selectedTimestamp,
}: Props) {
  const closes = bars.map((bar) => bar.close);
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const pad = (max - min) * 0.08 || max * 0.01;

  const visible = new Set(bars.map((bar) => bar.timestamp));
  const markers: MarkerDatum[] = signals
    .filter((signal) => visible.has(signal.timestamp))
    .map((signal) => ({
      timestamp: signal.timestamp,
      close: signal.close,
      signal,
    }));

  return (
    <figure className="m-0">
      <figcaption className="sr-only">
        Closing price over the selected period, with {markers.length} flagged
        observations marked.
      </figcaption>
      <div className="h-[19rem] w-full sm:h-[23rem]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={bars} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#5B8DEF" stopOpacity={0.22} />
                <stop offset="100%" stopColor="#5B8DEF" stopOpacity={0} />
              </linearGradient>
            </defs>

            <CartesianGrid stroke="#1D2633" vertical={false} />
            <XAxis
              dataKey="timestamp"
              tickFormatter={formatAxisTime}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={{ stroke: "#1D2633" }}
              tickLine={false}
              minTickGap={48}
            />
            <YAxis
              domain={[min - pad, max + pad]}
              tickFormatter={(value: number) => formatPrice(value, priceDecimals)}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={72}
              orientation="right"
            />
            <Tooltip content={<PriceTooltip />} cursor={{ stroke: "#3A4556" }} />

            <Area
              type="linear"
              dataKey="close"
              name="Close"
              stroke="#5B8DEF"
              strokeWidth={1.5}
              fill="url(#priceFill)"
              dot={false}
              activeDot={{ r: 3, fill: "#5B8DEF" }}
              isAnimationActive={false}
            />

            <Scatter
              data={markers}
              dataKey="close"
              name="Flagged observations"
              isAnimationActive={false}
              shape={(props: any) => (
                <SignalMarker
                  {...props}
                  onSelectSignal={onSelectSignal}
                  selectedTimestamp={selectedTimestamp}
                />
              )}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </figure>
  );
}
