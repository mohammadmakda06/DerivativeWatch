import { signalLabels } from "@/lib/format";
import type { SignalType } from "@/lib/types";

/**
 * Amber, not red. A flag means "worth a look", and the colour should not
 * suggest anything stronger than that.
 */
export default function SignalBadge({
  type,
  recent,
}: {
  type?: SignalType | null;
  recent?: boolean;
}) {
  const unusual = Boolean(type);
  const label = unusual
    ? recent
      ? "Unusual activity"
      : signalLabels[type as string]
    : "Normal activity";

  return (
    <span
      className={`inline-flex items-center gap-2 text-sm ${
        unusual ? "text-signal" : "text-muted"
      }`}
    >
      <span
        aria-hidden="true"
        className={`h-1.5 w-1.5 rounded-full ${
          unusual ? "bg-signal" : "bg-faint"
        }`}
      />
      {label}
    </span>
  );
}
