"use client";

import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { formatDate, formatSignedInteger } from "@/lib/format";
import type { CotObservation } from "@/lib/types";

function CotTooltip({ active, payload, speculativeLabel }: any) {
  if (!active || !payload?.length) return null;
  const point = payload[0].payload as CotObservation;
  return (
    <div className="border border-rule bg-panel px-3 py-2 text-xs">
      <p className="text-faint">{formatDate(point.reportDate)}</p>
      <p className="mt-1 text-muted">
        {speculativeLabel} net{" "}
        <span className="font-mono tabular text-text">
          {formatSignedInteger(point.speculativeNet)}
        </span>
      </p>
      {point.speculativeNetChange !== undefined ? (
        <p className="mt-0.5 text-muted">
          Weekly change{" "}
          <span className="font-mono tabular text-text">
            {formatSignedInteger(point.speculativeNetChange)}
          </span>
        </p>
      ) : null}
    </div>
  );
}

export default function CotChart({
  observations,
  speculativeLabel,
}: {
  observations: CotObservation[];
  speculativeLabel: string;
}) {
  return (
    <figure className="m-0">
      <figcaption className="sr-only">
        {speculativeLabel} net position, contracts, by weekly report date.
      </figcaption>
      <div className="h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={observations}
            margin={{ top: 8, right: 8, bottom: 0, left: 0 }}
          >
            <CartesianGrid stroke="#1D2633" vertical={false} />
            <XAxis
              dataKey="reportDate"
              tickFormatter={formatDate}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={{ stroke: "#1D2633" }}
              tickLine={false}
              minTickGap={56}
            />
            <YAxis
              tickFormatter={(value: number) => formatSignedInteger(value)}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={84}
              orientation="right"
            />
            <Tooltip
              content={<CotTooltip speculativeLabel={speculativeLabel} />}
              cursor={{ stroke: "#3A4556" }}
            />
            <ReferenceLine y={0} stroke="#3A4556" strokeDasharray="3 3" />
            <Line
              type="linear"
              dataKey="speculativeNet"
              name={`${speculativeLabel} net`}
              stroke="#5B8DEF"
              strokeWidth={1.75}
              dot={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </figure>
  );
}
