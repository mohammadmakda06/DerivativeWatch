import { formatTimestamp } from "@/lib/format";

export default function DataFreshness({
  timestamp,
  days,
}: {
  timestamp: string | null;
  days: number | null;
}) {
  if (!timestamp) return null;

  const stale = days !== null && days >= 3;

  return (
    <p className={`text-micro ${stale ? "text-signal" : "text-faint"}`}>
      {stale
        ? `Historical futures data · last observation ${days} days ago (${formatTimestamp(timestamp)} UTC)`
        : `Historical futures data · latest observation ${formatTimestamp(timestamp)} UTC`}
    </p>
  );
}
