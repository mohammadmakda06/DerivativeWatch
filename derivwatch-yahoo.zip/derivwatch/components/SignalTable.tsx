import { formatTimestamp, formatZScore, signalLabels } from "@/lib/format";
import type { SurveillanceSignal } from "@/lib/types";

export default function SignalTable({
  signals,
  limit = 10,
}: {
  signals: SurveillanceSignal[];
  limit?: number;
}) {
  if (signals.length === 0) {
    return (
      <p className="text-sm text-muted">
        No observations crossed the signal thresholds in this dataset.
      </p>
    );
  }

  const rows = [...signals].reverse().slice(0, limit);

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[34rem] border-collapse text-sm">
        <caption className="sr-only">
          Flagged observations, most recent first
        </caption>
        <thead>
          <tr className="border-b border-rule text-left">
            <th scope="col" className="rule-label py-2 pr-4 font-normal">
              Observed
            </th>
            <th scope="col" className="rule-label py-2 pr-4 font-normal">
              Signal
            </th>
            <th scope="col" className="rule-label py-2 pr-4 text-right font-normal">
              Price z
            </th>
            <th scope="col" className="rule-label py-2 pr-4 text-right font-normal">
              Volume z
            </th>
            <th scope="col" className="rule-label py-2 text-right font-normal">
              Score
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((signal) => (
            <tr key={signal.timestamp} className="border-b border-rule/60">
              <td className="py-2.5 pr-4 font-mono text-xs tabular text-muted">
                {formatTimestamp(signal.timestamp)}
              </td>
              <td className="py-2.5 pr-4 text-text">{signalLabels[signal.type]}</td>
              <td className="py-2.5 pr-4 text-right font-mono tabular text-text">
                {formatZScore(signal.priceZScore)}
              </td>
              <td className="py-2.5 pr-4 text-right font-mono tabular text-text">
                {formatZScore(signal.volumeZScore)}
              </td>
              <td className="py-2.5 text-right font-mono tabular text-signal">
                {signal.score}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {signals.length > rows.length ? (
        <p className="mt-3 text-micro text-faint">
          Showing the {rows.length} most recent of {signals.length} signals.
        </p>
      ) : null}
    </div>
  );
}
