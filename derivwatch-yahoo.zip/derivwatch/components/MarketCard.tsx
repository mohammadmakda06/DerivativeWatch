import Link from "next/link";

import { formatPercent, formatPrice, formatVolume } from "@/lib/format";
import type { MarketDataset } from "@/lib/types";

import SignalBadge from "./SignalBadge";

/** A signal within this many bars of the end of the series counts as recent. */
const RECENT_BARS = 24;

function hasRecentSignal(dataset: MarketDataset): boolean {
  const latest = dataset.summary.latestSignal;
  if (!latest || !dataset.stats.latestTimestamp) return false;
  const cutoffIndex = Math.max(0, dataset.bars.length - RECENT_BARS);
  const cutoff = dataset.bars[cutoffIndex]?.timestamp;
  return Boolean(cutoff && latest.timestamp >= cutoff);
}

export default function MarketCard({
  symbol,
  name,
  assetClass,
  dataset,
}: {
  symbol: string;
  name: string;
  assetClass: string;
  dataset: MarketDataset | null;
}) {
  if (!dataset) {
    return (
      <div className="panel flex h-full flex-col justify-between p-5">
        <div>
          <p className="font-mono text-xl text-text">{symbol}</p>
          <p className="mt-1 text-sm text-muted">{name}</p>
        </div>
        <p className="mt-6 text-sm text-faint">
          Market data unavailable. Run the data ingestion script to update this
          dataset.
        </p>
      </div>
    );
  }

  const { stats, summary } = dataset;
  const change = stats.latestChange;
  const tone = change === null ? "text-muted" : change >= 0 ? "text-up" : "text-down";
  const recent = hasRecentSignal(dataset);

  return (
    <Link
      href={`/markets/${symbol}`}
      className="panel group flex h-full flex-col justify-between p-5 transition-colors hover:border-faint"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xl text-text">{symbol}</p>
          <p className="mt-1 text-sm text-muted">{name}</p>
        </div>
        <span className="rule-label">{assetClass}</span>
      </div>

      <div className="mt-6 flex items-end justify-between gap-4">
        <div>
          <p className="font-mono text-2xl tabular text-text">
            {formatPrice(stats.latestClose)}
          </p>
          <p className={`font-mono text-sm tabular ${tone}`}>
            {formatPercent(change)}
          </p>
        </div>
        <div className="text-right">
          <p className="rule-label">Volume</p>
          <p className="font-mono text-sm tabular text-text">
            {formatVolume(stats.latestVolume)}
          </p>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between border-t border-rule pt-4">
        <SignalBadge
          type={recent ? summary.latestSignal?.type : undefined}
          recent
        />
        <span className="text-micro text-faint tabular">
          {summary.signalCount} signal{summary.signalCount === 1 ? "" : "s"}
        </span>
      </div>
    </Link>
  );
}
