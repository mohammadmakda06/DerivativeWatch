import { formatDate, formatInteger, formatSignedInteger } from "@/lib/format";
import type { CotSeries } from "@/lib/types";

import CotChart from "./CotChart";
import EmptyState from "./EmptyState";

function NetBlock({
  label,
  long,
  short,
  net,
  change,
}: {
  label: string;
  long: number;
  short: number;
  net: number;
  change?: number;
}) {
  return (
    <div className="panel p-4">
      <p className="text-sm text-text">{label}</p>
      <dl className="mt-3 space-y-2 text-sm">
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Long</dt>
          <dd className="font-mono tabular text-text">{formatInteger(long)}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Short</dt>
          <dd className="font-mono tabular text-text">{formatInteger(short)}</dd>
        </div>
        <div className="flex justify-between gap-4 border-t border-rule pt-2">
          <dt className="text-muted">Net</dt>
          <dd
            className={`font-mono tabular ${net >= 0 ? "text-up" : "text-down"}`}
          >
            {formatSignedInteger(net)}
          </dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt className="text-muted">Weekly change</dt>
          <dd className="font-mono tabular text-muted">
            {formatSignedInteger(change)}
          </dd>
        </div>
      </dl>
    </div>
  );
}

export default function CotPositioning({
  series,
  intermediary,
}: {
  series: CotSeries | null;
  intermediary: string | null;
}) {
  if (!series || series.observations.length === 0) {
    return (
      <section aria-labelledby="cot-heading" className="space-y-4">
        <h2 id="cot-heading" className="text-lg text-text">
          CFTC positioning
        </h2>
        <EmptyState
          title="Positioning data unavailable."
          body="No Commitments of Traders reports have been ingested for this market yet."
          action="python scripts/fetch_cot_data.py"
        />
      </section>
    );
  }

  const latest = series.observations[series.observations.length - 1];

  return (
    <section aria-labelledby="cot-heading" className="space-y-4">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 id="cot-heading" className="text-lg text-text">
          CFTC positioning
        </h2>
        <p className="text-micro text-faint">
          {series.reportName} · report date {formatDate(latest.reportDate)}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <NetBlock
          label={series.speculativeLabel}
          long={latest.speculativeLong}
          short={latest.speculativeShort}
          net={latest.speculativeNet}
          change={latest.speculativeNetChange}
        />
        <NetBlock
          label={series.hedgerLabel}
          long={latest.hedgerLong}
          short={latest.hedgerShort}
          net={latest.hedgerNet}
          change={latest.hedgerNetChange}
        />
        <div className="panel p-4">
          <p className="text-sm text-text">Open interest</p>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between gap-4">
              <dt className="text-muted">All contracts</dt>
              <dd className="font-mono tabular text-text">
                {formatInteger(latest.openInterest)}
              </dd>
            </div>
            <div className="flex justify-between gap-4 border-t border-rule pt-2">
              <dt className="text-muted">Weekly change</dt>
              <dd className="font-mono tabular text-muted">
                {formatSignedInteger(latest.openInterestChange)}
              </dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-muted">Market</dt>
              <dd className="max-w-[14rem] text-right text-xs text-muted">
                {series.marketName || "—"}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="panel p-4 sm:p-5">
        <p className="rule-label mb-2">
          {series.speculativeLabel} net position, weekly
        </p>
        <CotChart
          observations={series.observations}
          speculativeLabel={series.speculativeLabel}
        />
      </div>

      <aside className="panel p-5">
        <h3 className="text-sm text-text">What is CFTC positioning?</h3>
        <p className="mt-2 max-w-[68ch] text-sm leading-relaxed text-muted">
          The Commitments of Traders report provides aggregated information
          about positions held by different categories of market participants.
          DerivWatch uses the data as market context; positioning data is not
          treated as a prediction of future price movements.
        </p>
        <p className="mt-3 text-micro text-faint">
          Source: CFTC Commitments of Traders, {series.reportName}, contract
          market code {series.contractCode}
          {intermediary ? ` · retrieved via ${intermediary}` : ""}.
        </p>
      </aside>
    </section>
  );
}
