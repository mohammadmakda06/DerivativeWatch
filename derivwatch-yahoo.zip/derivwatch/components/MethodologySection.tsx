export default function MethodologySection({
  id,
  title,
  children,
}: {
  id: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section
      id={id}
      aria-labelledby={`${id}-heading`}
      className="border-t border-rule pt-8"
    >
      <h2 id={`${id}-heading`} className="text-lg text-text">
        {title}
      </h2>
      <div className="mt-3 max-w-[68ch] space-y-3 text-sm leading-relaxed text-muted">
        {children}
      </div>
    </section>
  );
}
