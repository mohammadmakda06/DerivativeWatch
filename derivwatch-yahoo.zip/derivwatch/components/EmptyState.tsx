export default function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: string;
}) {
  return (
    <div className="panel px-6 py-10 text-center">
      <p className="text-text">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted">
        {body}
      </p>
      {action ? (
        <code className="mt-4 inline-block border border-rule bg-ink px-3 py-1.5 font-mono text-xs text-muted">
          {action}
        </code>
      ) : null}
    </div>
  );
}
