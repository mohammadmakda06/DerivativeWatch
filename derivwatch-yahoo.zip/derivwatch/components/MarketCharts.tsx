"use client";

import { useMemo, useState } from "react";

import { formatTimestamp } from "@/lib/format";
import type { ChartBar, SurveillanceSignal } from "@/lib/types";

import PriceChart from "./PriceChart";
import SignalCard from "./SignalCard";
import VolumeChart from "./VolumeChart";

const RANGES = [
  { id: "7D", label: "7D", days: 7 },
  { id: "30D", label: "30D", days: 30 },
  { id: "90D", label: "90D", days: 90 },
  { id: "ALL", label: "All", days: null },
] as const;

type RangeId = (typeof RANGES)[number]["id"];

/**
 * Charts stay readable and fast by thinning the series once it exceeds this
 * many points. Flagged observations are always kept, so no marker is lost.
 */
const MAX_POINTS = 800;

function thin(bars: ChartBar[]): ChartBar[] {
  if (bars.length <= MAX_POINTS) return bars;
  const step = Math.ceil(bars.length / MAX_POINTS);
  return bars.filter(
    (bar, index) =>
      index % step === 0 || bar.signalType !== undefined || index === bars.length - 1,
  );
}

export default function MarketCharts({
  bars,
  signals,
  priceDecimals,
  volumeThreshold,
}: {
  bars: ChartBar[];
  signals: SurveillanceSignal[];
  priceDecimals: number;
  volumeThreshold: number;
}) {
  const latestSignal = signals.length ? signals[signals.length - 1] : null;
  const [range, setRange] = useState<RangeId>("30D");
  const [selected, setSelected] = useState<SurveillanceSignal | null>(latestSignal);

  const spanDays = useMemo(() => {
    if (bars.length < 2) return 0;
    const first = Date.parse(bars[0].timestamp);
    const last = Date.parse(bars[bars.length - 1].timestamp);
    return (last - first) / 86_400_000;
  }, [bars]);

  const available = RANGES.filter(
    (option) => option.days === null || option.days <= spanDays + 1,
  );

  const visibleBars = useMemo(() => {
    const option = RANGES.find((item) => item.id === range);
    if (!option || option.days === null) return thin(bars);
    const last = Date.parse(bars[bars.length - 1]?.timestamp ?? "");
    if (Number.isNaN(last)) return thin(bars);
    const cutoff = last - option.days * 86_400_000;
    return thin(bars.filter((bar) => Date.parse(bar.timestamp) >= cutoff));
  }, [bars, range]);

  const visibleSignals = useMemo(() => {
    if (visibleBars.length === 0) return [];
    const from = visibleBars[0].timestamp;
    const to = visibleBars[visibleBars.length - 1].timestamp;
    return signals.filter(
      (signal) => signal.timestamp >= from && signal.timestamp <= to,
    );
  }, [signals, visibleBars]);

  if (bars.length === 0) return null;

  return (
    <section aria-labelledby="price-activity" className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="price-activity" className="text-base text-text">
          Price and volume
        </h2>

        {available.length > 1 ? (
          <div
            role="group"
            aria-label="Chart date range"
            className="flex border border-rule"
          >
            {available.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setRange(option.id)}
                aria-pressed={range === option.id}
                className={`px-3 py-1.5 font-mono text-xs transition-colors ${
                  range === option.id
                    ? "bg-raised text-text"
                    : "text-muted hover:text-text"
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        ) : null}
      </div>

      <div className="panel p-4 sm:p-5">
        <PriceChart
          bars={visibleBars}
          signals={visibleSignals}
          priceDecimals={priceDecimals}
          onSelectSignal={setSelected}
          selectedTimestamp={selected?.timestamp ?? null}
        />
        <div className="mt-2 border-t border-rule pt-3">
          <p className="rule-label mb-1">Volume</p>
          <VolumeChart bars={visibleBars} threshold={volumeThreshold} />
        </div>
      </div>

      {visibleSignals.length > 0 ? (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-muted">
              {visibleSignals.length} flagged observation
              {visibleSignals.length === 1 ? "" : "s"} in view:
            </p>
            {visibleSignals.map((signal) => (
              <button
                key={signal.timestamp}
                type="button"
                onClick={() => setSelected(signal)}
                aria-pressed={selected?.timestamp === signal.timestamp}
                className={`border px-2.5 py-1 font-mono text-xs transition-colors ${
                  selected?.timestamp === signal.timestamp
                    ? "border-signal text-signal"
                    : "border-rule text-muted hover:border-faint hover:text-text"
                }`}
              >
                {formatTimestamp(signal.timestamp)}
              </button>
            ))}
          </div>

          {selected && visibleSignals.some((s) => s.timestamp === selected.timestamp) ? (
            <SignalCard signal={selected} />
          ) : (
            <p className="text-sm text-muted">
              Select a marker on the chart to see why it was flagged.
            </p>
          )}
        </div>
      ) : (
        <p className="text-sm text-muted">
          No observations in this range crossed the signal thresholds. Widen
          the range to look further back.
        </p>
      )}
    </section>
  );
}
