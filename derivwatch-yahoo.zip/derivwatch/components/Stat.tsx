export default function Stat({
  label,
  value,
  tone = "neutral",
  hint,
}: {
  label: string;
  value: string;
  tone?: "neutral" | "up" | "down" | "signal";
  hint?: string;
}) {
  const toneClass =
    tone === "up"
      ? "text-up"
      : tone === "down"
        ? "text-down"
        : tone === "signal"
          ? "text-signal"
          : "text-text";

  return (
    <div className="space-y-1">
      <dt className="rule-label">{label}</dt>
      <dd className={`font-mono text-lg tabular ${toneClass}`}>{value}</dd>
      {hint ? <p className="text-micro text-faint">{hint}</p> : null}
    </div>
  );
}
