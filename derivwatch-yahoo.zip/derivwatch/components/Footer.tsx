import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-rule">
      <div className="shell flex flex-col gap-6 py-8 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-md space-y-2">
          <p className="font-mono text-sm text-text">DerivWatch</p>
          <p className="text-sm leading-relaxed text-muted">
            DerivWatch identifies statistically unusual market activity. It does
            not determine whether manipulation, misconduct, or another
            regulatory violation occurred.
          </p>
        </div>

        <nav aria-label="Footer" className="flex gap-8 text-sm">
          <ul className="space-y-2">
            <li>
              <Link href="/markets" className="link-quiet">
                Markets
              </Link>
            </li>
            <li>
              <Link href="/methodology" className="link-quiet">
                Methodology
              </Link>
            </li>
          </ul>
          <ul className="space-y-2">
            <li>
              <a
                href="https://finance.yahoo.com/quote/ES%3DF/"
                className="link-quiet"
                rel="noreferrer noopener"
                target="_blank"
              >
                Yahoo Finance
              </a>
            </li>
            <li>
              <a
                href="https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm"
                className="link-quiet"
                rel="noreferrer noopener"
                target="_blank"
              >
                CFTC COT reports
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </footer>
  );
}
