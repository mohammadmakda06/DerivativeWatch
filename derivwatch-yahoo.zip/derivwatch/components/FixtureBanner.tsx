/**
 * Shown whenever a dataset on the page came from make-fixtures rather than
 * a real source. Synthetic numbers must never be mistaken for market
 * data, so this sits above the content rather than in a footnote.
 */
export default function FixtureBanner() {
  return (
    <div className="border border-signal/40 bg-signal/5 px-4 py-3 text-sm text-signal">
      Showing synthetic development fixtures, not market data. Run the
      ingestion scripts to replace them with real observations.
    </div>
  );
}
