import { contractList } from "@/lib/contracts";
import type { MarketDataset } from "@/lib/types";

import MarketCard from "./MarketCard";

export default function MarketGrid({
  datasets,
}: {
  datasets: { symbol: string; dataset: MarketDataset | null }[];
}) {
  const bySymbol = new Map(datasets.map((entry) => [entry.symbol, entry.dataset]));

  return (
    <ul className="grid grid-cols-1 gap-px bg-rule sm:grid-cols-2 lg:grid-cols-4">
      {contractList.map((contract) => (
        <li key={contract.symbol} className="bg-ink">
          <MarketCard
            symbol={contract.symbol}
            name={contract.name}
            assetClass={contract.assetClass}
            dataset={bySymbol.get(contract.symbol) ?? null}
          />
        </li>
      ))}
    </ul>
  );
}
