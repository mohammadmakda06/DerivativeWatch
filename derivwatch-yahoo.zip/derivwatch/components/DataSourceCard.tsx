export default function DataSourceCard({
  role,
  name,
  description,
  href,
  linkLabel,
}: {
  role: string;
  name: string;
  description: string;
  href?: string;
  linkLabel?: string;
}) {
  return (
    <div className="panel flex h-full flex-col p-5">
      <p className="rule-label">{role}</p>
      <p className="mt-2 font-mono text-base text-text">{name}</p>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted">
        {description}
      </p>
      {href ? (
        <a
          href={href}
          target="_blank"
          rel="noreferrer noopener"
          className="mt-4 text-sm text-accent transition-colors hover:text-text"
        >
          {linkLabel ?? "Source"}
        </a>
      ) : null}
    </div>
  );
}
