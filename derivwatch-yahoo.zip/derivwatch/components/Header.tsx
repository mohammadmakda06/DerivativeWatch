import Link from "next/link";

import NavLink from "./NavLink";

export default function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-rule bg-ink/90 backdrop-blur">
      <div className="shell flex h-14 items-center justify-between gap-6">
        <Link
          href="/"
          className="flex items-baseline gap-2.5"
          aria-label="DerivWatch home"
        >
          <span className="font-mono text-[0.95rem] font-medium tracking-tight text-text">
            DerivWatch
          </span>
          <span className="hidden text-micro text-faint sm:inline">
            futures market intelligence
          </span>
        </Link>

        <nav aria-label="Primary">
          <ul className="flex items-center gap-1 text-sm">
            <li>
              <NavLink href="/markets">Markets</NavLink>
            </li>
            <li>
              <NavLink href="/methodology">Methodology</NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
