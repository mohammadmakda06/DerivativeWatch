"use client";

import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import {
  formatAxisTime,
  formatTimestamp,
  formatVolume,
  formatZScore,
} from "@/lib/format";
import type { ChartBar } from "@/lib/types";

function VolumeTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const point = payload[0].payload as ChartBar;
  return (
    <div className="border border-rule bg-panel px-3 py-2 text-xs">
      <p className="font-mono tabular text-text">{formatVolume(point.volume)}</p>
      <p className="mt-1 text-muted">
        Volume z-score {formatZScore(point.volumeZScore)}
      </p>
      <p className="mt-1 text-faint">{formatTimestamp(point.timestamp)} UTC</p>
    </div>
  );
}

export default function VolumeChart({
  bars,
  threshold,
}: {
  bars: ChartBar[];
  threshold: number;
}) {
  return (
    <figure className="m-0">
      <figcaption className="sr-only">
        Traded volume per observation. Bars at or above {threshold} standard
        deviations from their rolling baseline are highlighted.
      </figcaption>
      <div className="h-32 w-full sm:h-40">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={bars} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
            <XAxis
              dataKey="timestamp"
              tickFormatter={formatAxisTime}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={{ stroke: "#1D2633" }}
              tickLine={false}
              minTickGap={48}
            />
            <YAxis
              tickFormatter={(value: number) => formatVolume(value)}
              tick={{ fill: "#5F6B7D", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={72}
              orientation="right"
            />
            <Tooltip
              content={<VolumeTooltip />}
              cursor={{ fill: "rgba(91,141,239,0.06)" }}
            />
            <Bar dataKey="volume" isAnimationActive={false}>
              {bars.map((bar) => {
                const unusual =
                  bar.volumeZScore !== undefined && bar.volumeZScore >= threshold;
                return (
                  <Cell
                    key={bar.timestamp}
                    fill={unusual ? "#D9A441" : "#2C3A4E"}
                  />
                );
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </figure>
  );
}
